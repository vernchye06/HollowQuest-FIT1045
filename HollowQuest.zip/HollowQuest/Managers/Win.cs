﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mime;
using Microsoft.Xna.Framework.Media;
using MonoGame.Extended;
using System.Xml.Serialization;

namespace Hollow_Quest.Managers
{
    public class Win
    {
        private SpriteFont font;
        private Texture2D pixel;
        private Vector2 screenSize;

        public Vector2 blackBoxSize;

        private Vector2 textSizeWin;
        private Vector2 textSizeReturn;

        private SoundEffect winSound;
        public bool playedSFX = false;

        public Win(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
            getTextSize();
            blackBoxSize = new Vector2(screenSize.X / 64, screenSize.Y / 64);
        }

        public void LoadContent(ContentManager content)
        {
            winSound = content.Load<SoundEffect>("SFX/win");
        }

        public void Update(GameTime gameTime, int score)
        {
            determineBlackBoxSpeed();
            playMusic();
        }

        public void Draw(SpriteBatch spriteBatch, int score)
        {
            spriteBatch.Draw // draw black overlay
                (
                    pixel,
                    new Rectangle(0, 0, (int)blackBoxSize.X, (int)blackBoxSize.Y),
                    Color.Black
                );

            spriteBatch.DrawString // draw "You Win!" text
                (
                    font,
                    "You Win!",
                    new Vector2(
                        ((int)screenSize.X - textSizeWin.X) / 2,
                        ((int)screenSize.Y - textSizeWin.Y) / 3
                        ),
                    Color.Gold
                );

            spriteBatch.DrawString // draw final score text
                (
                    font,
                    "Final Score: " + score,
                    new Vector2(
                        ((int)screenSize.X - font.MeasureString("Final Score: " + score).X) / 2,
                        ((int)screenSize.Y - font.MeasureString("Final Score: " + score).Y) / 2
                        ),
                    Color.White
                );

            spriteBatch.DrawString // draw "Press Enter to Return to Main Menu" text
                (
                    font,
                    "Press Enter to Return to Main Menu",
                    new Vector2(
                        ((int)screenSize.X - textSizeReturn.X) / 2,
                        ((int)screenSize.Y - textSizeReturn.Y) * 3 / 4
                        ),
                    Color.White
                );
        }

        private void determineBlackBoxSpeed()
        {
            if (screenSize.X < 1000)
            {
                blackBoxSize += new Vector2(6f, 3.375f);
            }
            else
            {
                blackBoxSize += new Vector2(12f, 6.75f);
            }
        }

        private void playMusic()
        {
            if (!playedSFX)
            {
                winSound.Play();
                playedSFX = true;
            }
        }

        private void getTextSize()
        {
            textSizeWin = font.MeasureString("You Win!");
            textSizeReturn = font.MeasureString("Press Enter to Return to Main Menu");
        }

        public void Update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }
    }
}
