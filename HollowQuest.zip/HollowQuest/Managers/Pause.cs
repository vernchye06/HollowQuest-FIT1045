﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hollow_Quest.Managers
{
    public class Pause
    {
        private SpriteFont font;
        private Texture2D pixel;
        private Vector2 screenSize;
        private Vector2 textSizePause;
        private Vector2 textSizeResume;

        public Pause(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
            getTextSize();
        }

        public void getTextSize()
        {
            textSizePause = font.MeasureString("Game Paused");
            textSizeResume = font.MeasureString("Press P to Resume");
        }

        public void update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }

        public void draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw
                (
                    pixel,
                    new Rectangle(0, 0, (int)screenSize.X, (int)screenSize.Y),
                    Color.Black * 0.5f
                );

            spriteBatch.DrawString
                (
                    font,
                    "Game Paused",
                    new Vector2(
                        ((int)screenSize.X - textSizePause.X) / 2, 
                        ((int)screenSize.Y - textSizePause.Y) / 3
                        ),
                    Color.White
                );
            spriteBatch.DrawString
                (
                font,
                "Press P to Resume",
                new Vector2(
                    ((int)screenSize.X - textSizeResume.X) / 2,
                    ((int)screenSize.Y - textSizeResume.Y) / 2
                    ),
                Color.White
                );
        }
    }
}
