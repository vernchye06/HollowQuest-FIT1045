﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hollow_Quest.Managers
{
    public class GameOver
    {
        private SpriteFont font;
        private Texture2D pixel;
        private Vector2 screenSize;
        private Vector2 textSizeOver;
        private Vector2 textSizeRestart;
        private Vector2 textSizeReturn;

        public GameOver(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
            getTextSize();
        }
        public void update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }

        public void getTextSize()
        {
            textSizeOver = font.MeasureString("Game Over!");
            textSizeRestart = font.MeasureString("Press Enter to Restart");
            textSizeReturn = font.MeasureString("Press Backspace to go to Main Menu");
        }

        public void draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw
                (
                    pixel,
                    new Rectangle(0, 0, (int)screenSize.X, (int)screenSize.Y),
                    Color.Black * 0.5f
                );

            spriteBatch.DrawString
                (
                    font, 
                    "Game Over!", 
                    new Vector2(
                        ((int)screenSize.X - textSizeOver.X) / 2,
                        ((int)screenSize.Y - textSizeReturn.Y) / 3
                        ), 
                    Color.Red
                );

            spriteBatch.DrawString
                (
                    font, 
                    "Press Enter to Restart", 
                    new Vector2(
                        ((int)screenSize.X - textSizeRestart.X) / 2,
                        ((int)screenSize.Y - textSizeRestart.Y) / 2
                        ), 
                    Color.White
                );
            spriteBatch.DrawString
                (
                    font,
                    "Press Backspace to go to Main Menu",
                    new Vector2(
                        ((int)screenSize.X - textSizeReturn.X) / 2,
                        ((int)screenSize.Y - textSizeReturn.Y) / 3 * 2
                        ),
                    Color.White
                );
        }
    }
}
