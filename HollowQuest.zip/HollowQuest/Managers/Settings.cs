﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;

namespace Hollow_Quest.Managers
{
    public class Settings
    {
        private SpriteFont font;
        private Texture2D pixel;

        private Vector2 screenSize;
        public int volumeLevel = 100;

        private Vector2 textSizeSettings;
        private Vector2 textSizeVolumeAdjust;
        private Vector2 textSizeReturn;
        private Vector2 textSizeFullscreen;

        private bool keyUp = true;
        public bool isFullscreen = false;

        private Vector2 mousePosition;
        private bool mouseReleased = true;


        public Settings(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
            getTextSize();
        }

        public void Update(KeyboardState kState)
        {
            HandleInput(kState);
            HandleMouseClick();
        }

        public void update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }

        private void HandleInput(KeyboardState kState)
        {
            if (kState.IsKeyDown(Keys.Up) && keyUp)
            {
                AdjustVolume(5);
                keyUp = false;
            }
            else if (kState.IsKeyDown(Keys.Down) && keyUp)
            {
                AdjustVolume(-5);
                keyUp = false;
            }
            if (kState.IsKeyUp(Keys.Up) && kState.IsKeyUp(Keys.Down))
            {
                keyUp = true;
            }
        }
        private void HandleMouseClick()
        {
            MouseState mouseState = Mouse.GetState();
            mousePosition = new Vector2(mouseState.X, mouseState.Y);

            if (mouseState.LeftButton == ButtonState.Pressed)
            {
                Rectangle fullscreenRect = new Rectangle(
                     ((int)screenSize.X - (int)textSizeFullscreen.X) / 2 - 5,
                     ((int)screenSize.Y - (int)textSizeFullscreen.Y) / 2 + 115,
                     (int)textSizeFullscreen.X + 5,
                     (int)textSizeFullscreen.Y + 5
                    );
                if (fullscreenRect.Contains(mousePosition) && mouseReleased)
                {
                    if (isFullscreen)
                    {
                        isFullscreen = false;
                    }  
                    else
                    {
                        isFullscreen = true;
                    }        
                }
                mouseReleased = false;
            }
            if (mouseState.LeftButton == ButtonState.Released)
            {
                mouseReleased = true;
            }
        }

        private void AdjustVolume(int change)
        {
            volumeLevel += change;
            volumeLevel = Math.Clamp(volumeLevel, 0, 100);
        }

        public void getTextSize()
        {
            textSizeSettings = font.MeasureString("Settings");
            textSizeVolumeAdjust = font.MeasureString("Press Up/Down to Adjust Volume");
            textSizeReturn = font.MeasureString("Press Enter to Return to Menu");
            textSizeFullscreen = font.MeasureString("Fullscreen Mode");
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw
                (
                    pixel,
                    new Rectangle(0, 0, (int)screenSize.X, (int)screenSize.Y),
                    Color.Black * 0.8f
                );

            spriteBatch.Draw
                (
                    pixel,
                    new Rectangle
                    (
                        ((int)screenSize.X - (int)textSizeSettings.X) / 2 - 5,
                        ((int)screenSize.Y - (int)textSizeSettings.Y) / 4 - 5,
                        (int)textSizeSettings.X + 5,
                        (int)textSizeSettings.Y + 5
                    ),
                    Color.Gray
                );

            spriteBatch.DrawString
                (
                    font,
                    "Settings",
                    new Vector2(
                        ((int)screenSize.X - textSizeSettings.X) / 2,
                        ((int)screenSize.Y - textSizeSettings.Y) / 4
                        ),
                    Color.White
                );

            spriteBatch.DrawString
                (
                    font,
                    "Volume: " + volumeLevel + "%",
                    new Vector2(
                        ((int)screenSize.X - font.MeasureString("Volume: " + volumeLevel + "%").X) / 2,
                        ((int)screenSize.Y - font.MeasureString("Volume: " + volumeLevel + "%").Y) / 2
                        ),
                    Color.White
                );

            spriteBatch.DrawString
                (
                    font,
                    "Press Up/Down to Adjust Volume",
                    new Vector2(
                        ((int)screenSize.X - textSizeVolumeAdjust.X) / 2,
                        ((int)screenSize.Y - textSizeVolumeAdjust.Y) / 2 + 40
                        ),
                    Color.White
                );

            spriteBatch.DrawString
                (
                    font,
                    "Press Enter to Return to Menu",
                    new Vector2(
                        ((int)screenSize.X - textSizeReturn.X) / 2,
                        ((int)screenSize.Y - textSizeReturn.Y) / 2 + 80
                        ),
                    Color.White
                );

            if (isFullscreen)
            {
                spriteBatch.Draw
                (
                    pixel,
                    new Rectangle
                    (
                        ((int)screenSize.X - (int)textSizeFullscreen.X) / 2 - 5,
                        ((int)screenSize.Y - (int)textSizeFullscreen.Y) / 2 + 115,
                        (int)textSizeFullscreen.X + 5,
                        (int)textSizeFullscreen.Y + 5
                    ),
                    Color.Black
                );
            }
            
            spriteBatch.DrawString
                (
                    font,
                    "Fullscreen Mode",
                    new Vector2(
                        ((int)screenSize.X - textSizeFullscreen.X) / 2,
                        ((int)screenSize.Y - textSizeFullscreen.Y) / 2 + 120
                        ),
                    Color.White
                );
        }
    }
}
