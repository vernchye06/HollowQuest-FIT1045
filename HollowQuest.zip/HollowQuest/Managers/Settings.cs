﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;

namespace Hollow_Quest.Managers
{
    public class Settings
    {
        private SpriteFont font;
        private Texture2D pixel;

        private Vector2 screenSize;
        public int volumeLevel = 100;

        private Vector2 textSizeSettings;
        private Vector2 textSizeVolumeAdjust;
        private Vector2 textSizeReturn;
        private Vector2 textSizeFullscreen;

        private bool keyUp = true;   
        private bool mouseReleased = true;
        public bool isFullscreen = false;


        public Settings(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
            getTextSize();
        }

        public void Update(KeyboardState kState, MouseState mState)
        {
            HandleInput(kState);
            HandleMouseClick(mState);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw // draw semi-transparent black overlay
                (
                    pixel,
                    new Rectangle(0, 0, (int)screenSize.X, (int)screenSize.Y),
                    Color.Black * 0.8f
                );

            spriteBatch.Draw // draw settings box background
                (
                    pixel,
                    new Rectangle
                    (
                        ((int)screenSize.X - (int)textSizeSettings.X) / 2 - 5,
                        ((int)screenSize.Y - (int)textSizeSettings.Y) / 4 - 5,
                        (int)textSizeSettings.X + 5,
                        (int)textSizeSettings.Y + 5
                    ),
                    Color.Gray
                );

            spriteBatch.DrawString // draw "Settings" text
                (
                    font,
                    "Settings",
                    new Vector2(
                        ((int)screenSize.X - textSizeSettings.X) / 2,
                        ((int)screenSize.Y - textSizeSettings.Y) / 4
                        ),
                    Color.White
                );

            spriteBatch.DrawString // draw "Volume Level" text
                (
                    font,
                    "Volume: " + volumeLevel + "%",
                    new Vector2(
                        ((int)screenSize.X - font.MeasureString("Volume: " + volumeLevel + "%").X) / 2,
                        ((int)screenSize.Y - font.MeasureString("Volume: " + volumeLevel + "%").Y) / 2
                        ),
                    Color.White
                );

            spriteBatch.DrawString // draw "Press Up/Down to Adjust Volume" text
                (
                    font,
                    "Press Up/Down to Adjust Music Volume",
                    new Vector2(
                        ((int)screenSize.X - textSizeVolumeAdjust.X) / 2,
                        ((int)screenSize.Y - textSizeVolumeAdjust.Y) / 2 + 40
                        ),
                    Color.White
                );

            spriteBatch.DrawString // draw "Press Enter to Return to Menu" text
                (
                    font,
                    "Press Enter to Return to Menu",
                    new Vector2(
                        ((int)screenSize.X - textSizeReturn.X) / 2,
                        ((int)screenSize.Y - textSizeReturn.Y) / 2 + 80
                        ),
                    Color.White
                );

            if (isFullscreen)
            {
                spriteBatch.Draw // draw fullscreen mode box
                (
                    pixel,
                    new Rectangle
                    (
                        ((int)screenSize.X - (int)textSizeFullscreen.X) / 2 - 5,
                        ((int)screenSize.Y - (int)textSizeFullscreen.Y) / 2 + 115,
                        (int)textSizeFullscreen.X + 5,
                        (int)textSizeFullscreen.Y + 5
                    ),
                    Color.Black
                );
            }

            spriteBatch.DrawString // draw "Fullscreen Mode" text
                (
                    font,
                    "Fullscreen Mode",
                    new Vector2(
                        ((int)screenSize.X - textSizeFullscreen.X) / 2,
                        ((int)screenSize.Y - textSizeFullscreen.Y) / 2 + 120
                        ),
                    Color.White
                );
        }

        private void getTextSize()
        {
            textSizeSettings = font.MeasureString("Settings");
            textSizeVolumeAdjust = font.MeasureString("Press Up/Down to Adjust Music Volume");
            textSizeReturn = font.MeasureString("Press Enter to Return to Menu");
            textSizeFullscreen = font.MeasureString("Fullscreen Mode");
        }

        private void HandleInput(KeyboardState kState)
        {
            if (kState.IsKeyDown(Keys.Up) && keyUp)
            {
                AdjustVolume(5);
                keyUp = false;
            }
            else if (kState.IsKeyDown(Keys.Down) && keyUp)
            {
                AdjustVolume(-5);
                keyUp = false;
            }
            if (kState.IsKeyUp(Keys.Up) && kState.IsKeyUp(Keys.Down))
            {
                keyUp = true;
            }
        }

        private void HandleMouseClick(MouseState mState)
        {
            Vector2 mousePosition = new Vector2(mState.X, mState.Y);

            if (mState.LeftButton == ButtonState.Pressed)
            {
                Rectangle fullscreenRect = new Rectangle(
                     ((int)screenSize.X - (int)textSizeFullscreen.X) / 2 - 5,
                     ((int)screenSize.Y - (int)textSizeFullscreen.Y) / 2 + 115,
                     (int)textSizeFullscreen.X + 5,
                     (int)textSizeFullscreen.Y + 5
                    );
                if (fullscreenRect.Contains(mousePosition) && mouseReleased)
                {
                    if (isFullscreen)
                    {
                        isFullscreen = false;
                    }
                    else
                    {
                        isFullscreen = true;
                    }
                }
                mouseReleased = false;
            }
            if (mState.LeftButton == ButtonState.Released)
            {
                mouseReleased = true;
            }
        }

        private void AdjustVolume(int change)
        {
            volumeLevel += change;
            volumeLevel = Math.Clamp(volumeLevel, 0, 100);
        }

        public void Update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }
    }
}
