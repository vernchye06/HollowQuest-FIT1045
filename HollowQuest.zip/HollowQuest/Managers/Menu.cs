﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Hollow_Quest.Managers
{
    public class Menu
    {
        private SpriteFont font;
        private Texture2D pixel;
        private Vector2 screenSize;

        private Vector2 textSizeName;
        private Vector2 textSizeStart;

        private Texture2D swordTexture;
        private Vector2 swordPosition;

        private Texture2D settingsTexture;
        private Texture2D knightTexture;

        private Song bgMusic;

        private Vector2 mousePosition;

        public Menu(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
            swordPosition = new Vector2((int)screenSize.X / 2 - 64, (int)screenSize.Y / 2 - 64);
            getTextSize();
        }

        public void LoadContent(ContentManager content)
        {
            knightTexture = content.Load<Texture2D>("menu/knight_menu");
            swordTexture = content.Load<Texture2D>("menu/sword");
            settingsTexture = content.Load<Texture2D>("menu/gear");
            bgMusic = content.Load<Song>("BGM/main_menu");
        }

        public void Update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
            swordPosition = new Vector2((int)screenSize.X / 2 - 64, (int)screenSize.Y / 2 - 64);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw // draw sky blue background
                (
                    pixel,
                    new Rectangle(0, 0, (int)screenSize.X, (int)screenSize.Y),
                    Color.SkyBlue
                );

            spriteBatch.Draw // draw knight image
                (
                    knightTexture,
                    new Rectangle(
                        0,
                        (int)(screenSize.Y * 3 / 4 - 256),
                        256,
                        256
                        ),
                    Color.White
                );

            spriteBatch.Draw // draw background rectangle
                (
                    pixel,
                    new Rectangle(
                        (int)screenSize.X / 4,
                        (int)screenSize.Y / 4,
                        (int)screenSize.X / 2,
                        (int)screenSize.Y / 2
                        ),
                    Color.SlateGray
                );

            spriteBatch.Draw // draw grass
                (
                    pixel,
                    new Rectangle(
                        0,
                        (int)(screenSize.Y * 3 / 4),
                        (int)screenSize.X,
                        (int)(screenSize.Y / 4)
                        ),
                    Color.ForestGreen
                );

            spriteBatch.Draw // draw sword image
                (
                    swordTexture,
                    new Rectangle(
                        (int)swordPosition.X,
                        (int)swordPosition.Y,
                        128,
                        128
                        ),
                    Color.White
                );

            spriteBatch.Draw // draw settings gear icon
                (
                    settingsTexture,
                    new Rectangle(
                        (int)screenSize.X - 69,
                        (int)screenSize.Y - 69,
                        64,
                        64
                        ),
                    Color.White
                );

            spriteBatch.DrawString // draw game title
                (
                    font,
                    "Hollow Quest",
                    new Vector2(
                        ((int)screenSize.X - textSizeName.X) / 2,
                        ((int)screenSize.Y - textSizeName.Y) / 3
                        ),
                    Color.White
                );
            spriteBatch.DrawString // draw start prompt
                (
                    font,
                    "Press Space to Start",
                    new Vector2(
                        ((int)screenSize.X - textSizeStart.X) / 2,
                        ((int)screenSize.Y - textSizeStart.Y) / 2
                        ),
                    Color.White
                );
        }

        public void getTextSize()
        {
            textSizeName = font.MeasureString("Hollow Quest");
            textSizeStart = font.MeasureString("Press Space to Start");
        }

        public void playMusic()
        {
            MediaPlayer.Stop();
            MediaPlayer.Play(bgMusic);
        }

        public void moveSword(float elapsed)
        {
            swordPosition.Y += (float)(50 * Math.Sin(DateTime.Now.TimeOfDay.TotalSeconds * 2)) * elapsed;
        }

        public bool HandleMouseClick()
        {
            MouseState mouseState = Mouse.GetState();
            mousePosition = new Vector2(mouseState.X, mouseState.Y);

            if (mouseState.LeftButton == ButtonState.Pressed)
            {
                Rectangle settingsRect = new Rectangle(
                    (int)screenSize.X - 69,
                    (int)screenSize.Y - 69,
                    64,
                    64
                    );
                if (settingsRect.Contains(mousePosition))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
