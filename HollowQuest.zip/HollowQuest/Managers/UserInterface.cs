﻿using Hollow_Quest.World;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hollow_Quest.Managers
{
    public class UserInterface
    {
        private SpriteFont font;
        private Texture2D pixel;
        private Vector2 screenSize;

        public UserInterface(SpriteFont font, Texture2D pixel, Vector2 screenSize)
        {
            this.font = font;
            this.pixel = pixel;
            this.screenSize = screenSize;
        }

        public void Update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }

        public void Draw(SpriteBatch spriteBatch, int score, int health)
        {
            spriteBatch.Draw // draw semi-transparent black bar at the top
                (
                pixel,
                new Rectangle(0, 0, (int)screenSize.X, 40),
                Color.Black * 0.5f
                );

            spriteBatch.DrawString // draw score text
                (
                font, 
                "Score: " + score, 
                new Vector2(10, 10), 
                Color.Silver
                );

            spriteBatch.DrawString // draw health text
                (
                font,
                "Health:",
                new Vector2(screenSize.X - 325, 10),
                Color.Silver
                );

            spriteBatch.Draw // draw health bar background
                (
                pixel,
                new Rectangle((int)screenSize.X - 210, 10, 200, 20),
                Color.Red
                );

            spriteBatch.Draw // draw health bar foreground
                (
                pixel,
                new Rectangle((int)screenSize.X - 210, 10, 40 * health, 20),
                Color.ForestGreen
                );
        }
    }
}
