﻿using Hollow_Quest.Entities;
using Hollow_Quest.Managers;
using Hollow_Quest.World;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Diagnostics;
using System.IO;


namespace Hollow_Quest
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private enum GameState
        {
            Menu,
            Settings,
            Playing,
            Pause,
            Win,
            GameOver
        } private GameState game1;

        public SpriteFont font;
        public Texture2D pixel;

        private Level level1;
        
        private bool gamePauseKeyUp = true;
        private Pause pauseMenu;
        private GameOver gameOverScreen;
        private Menu mainMenu;
        private Settings settingsMenu;
        private Win winScreen;

        private UserInterface gui;

        private Vector2 screenSize;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {

            level1 = new Level();
            game1 = GameState.Menu; // Start in the Menu state

            MediaPlayer.IsRepeating = true;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            screenSize = new Vector2(GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height); // Get screen size

            font = Content.Load<SpriteFont>("font");
            LoadPixel(); // Load a 1x1 pixel texture

            LoadGameStates();
            mainMenu.playMusic();
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            KeyboardState kState = Keyboard.GetState();
            MouseState mState = Mouse.GetState(); 

            switch (game1)
                {
                    case GameState.Menu:
                        if (kState.IsKeyDown(Keys.Space))
                        {
                            HandleStartGame();
                        } 
                        if (mainMenu.HandleMouseClick())
                        {
                            game1 = GameState.Settings;
                        }
                        mainMenu.moveSword((float)gameTime.ElapsedGameTime.TotalSeconds);
                        break;
                    case GameState.Settings:
                        if (kState.IsKeyDown(Keys.Enter))
                        {
                            mainMenu.playMusic();
                            game1 = GameState.Menu;
                        }
                        settingsMenu.Update(kState, mState);
                        SetVolume(settingsMenu.volumeLevel);
                        HandleFullScreen();
                        break;
                    case GameState.Playing: 
                        if (!level1.player.isAlive)
                        {
                            game1 = GameState.GameOver;
                        }
                        else if (kState.IsKeyDown(Keys.P) && gamePauseKeyUp)
                        {
                            game1 = GameState.Pause;
                            gamePauseKeyUp = false;
                        }
                        if (level1.player.reachedEnd)
                        {
                            game1 = GameState.Win;
                        }
                        gui.Update(screenSize);
                        level1.Update(gameTime);
                        break;
                    case GameState.Pause:
                        if (kState.IsKeyDown(Keys.P) && gamePauseKeyUp)
                        {
                            MediaPlayer.Resume();
                            game1 = GameState.Playing;
                            gamePauseKeyUp = false;
                        }  
                        break;
                    case GameState.Win:
                        winScreen.Update(gameTime, level1.score);
                        if (kState.IsKeyDown(Keys.Enter))
                            {
                                winScreen.blackBoxSize = new Vector2(screenSize.X / 64, screenSize.Y / 64);
                                winScreen.playedSFX = false;
                                mainMenu.playMusic();
                                game1 = GameState.Menu;
                            } 
                        break;
                    case GameState.GameOver:
                        if (kState.IsKeyDown(Keys.Enter))
                        {
                            HandleStartGame();
                        }
                        else if (kState.IsKeyDown(Keys.Back))
                        {
                            mainMenu.playMusic();
                            game1 = GameState.Menu;
                        }
                        level1.Update(gameTime);
                        break;
                    default:
                        break;
                }

            HandlePauseMusic();

            if (kState.IsKeyUp(Keys.P))
            {
                gamePauseKeyUp = true;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(20, 152, 220));

            _spriteBatch.Begin(samplerState: SamplerState.PointClamp);

            switch (game1)
            {
                case GameState.Menu:
                    mainMenu.Draw(_spriteBatch);
                    break;
                case GameState.Settings:
                    settingsMenu.Draw(_spriteBatch);
                    break;
                case GameState.Playing:
                    DrawLevel();
                    break;
                case GameState.Pause:
                    DrawLevel();
                    pauseMenu.Draw(_spriteBatch);
                    break;
                case GameState.Win:
                    level1.Draw(_spriteBatch);
                    winScreen.Draw(_spriteBatch, level1.score);
                    break;
                case GameState.GameOver:
                    DrawLevel();
                    gameOverScreen.Draw(_spriteBatch);
                    break;
                default:
                    break;
            }
            
            _spriteBatch.End();

            base.Draw(gameTime);
        }

        private void LoadPixel()
        {
            pixel = new Texture2D(GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });
        }

        private void LoadGameStates()
        {
            mainMenu = new Menu(font, pixel, screenSize);
            mainMenu.LoadContent(Content);

            settingsMenu = new Settings(font, pixel, screenSize);

            gui = new UserInterface(font, pixel, screenSize);
            level1 = new Level();
            level1.LoadContent(Content, GraphicsDevice);
            level1.Initialize();

            pauseMenu = new Pause(font, pixel, screenSize);

            gameOverScreen = new GameOver(font, pixel, screenSize);

            winScreen = new Win(font, pixel, screenSize);
            winScreen.LoadContent(Content);
        }

        private void HandleStartGame()
        {
            level1.LoadContent(Content, GraphicsDevice);
            level1.Initialize();
            UpdateScreenSize();
            level1.score = 0;

            level1.PlayMusic();
            game1 = GameState.Playing;
        }

        private void HandleFullScreen()
        {
            if (settingsMenu.isFullscreen)
            {
                screenSize = new Vector2(
                    GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width,
                    GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height - 70
                    ); // Subtracting 70 to account for taskbar
                _graphics.PreferredBackBufferWidth = (int)screenSize.X;
                _graphics.PreferredBackBufferHeight = (int)screenSize.Y;
                _graphics.ApplyChanges();
                UpdateScreenSize();
            }
            else
            {
                screenSize = new Vector2(800, 480); // Default windowed size
                _graphics.PreferredBackBufferWidth = (int)screenSize.X;
                _graphics.PreferredBackBufferHeight = (int)screenSize.Y;
                _graphics.ApplyChanges();
                UpdateScreenSize();
            }
        }

        private void UpdateScreenSize()
        {
            mainMenu.Update(screenSize);
            settingsMenu.Update(screenSize);
            level1.Update(screenSize);
            pauseMenu.Update(screenSize);
            gameOverScreen.Update(screenSize);
            winScreen.Update(screenSize);
        }

        private void SetVolume(int volumeLevel)
        {
            float volume = volumeLevel / 100f;
            MediaPlayer.Volume = volume;
        }

        private void HandlePauseMusic()
        {
            if (!(game1 == GameState.Playing || game1 == GameState.Menu))
            {
                MediaPlayer.Pause();
            }
        }

        private void DrawLevel()
        {
            level1.Draw(_spriteBatch);
            gui.Draw(_spriteBatch, level1.score, level1.player.health);
        }
    }
}
