﻿using Hollow_Quest.Entities;
using Hollow_Quest.Managers;
using Hollow_Quest.World;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;


namespace Hollow_Quest
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        public SpriteFont font;

        private Level level1;

        private Pause pauseMenu;
        private bool gamePauseKeyUp = true;
        private GameOver gameOverScreen;
        private Menu mainMenu;
        private Settings settingsMenu;
        private Win winScreen;
        private UserInterface gui;

        private Vector2 screenSize;

        public enum GameState
        {
            Menu,
            Settings,
            Playing,
            Pause,
            Win,
            GameOver
        }

        public GameState game1;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {

            level1 = new Level();

            game1 = GameState.Menu;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            font = Content.Load<SpriteFont>("font");

            Texture2D pixel = new Texture2D(GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            screenSize = new Vector2(GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

            pauseMenu = new Pause(font, pixel, screenSize);

            gameOverScreen = new GameOver(font, pixel, screenSize);

            mainMenu = new Menu(font, pixel, screenSize);
            mainMenu.loadContent(Content);

            settingsMenu = new Settings(font, pixel, screenSize);

            winScreen = new Win(font, pixel, screenSize);
            winScreen.loadContent(Content);

            gui = new UserInterface(font, pixel, screenSize);

            level1.LoadContent(Content, GraphicsDevice);

            MediaPlayer.IsRepeating = true;
            mainMenu.playMusic();
        }

        private void SetVolume(int volumeLevel)
        {
            float volume = volumeLevel / 100f;
            MediaPlayer.Volume = volume;
        }

        private void updateScreenSize()
        {
            mainMenu.update(screenSize);
            settingsMenu.update(screenSize);
            level1.update(screenSize);
            pauseMenu.update(screenSize);
            gameOverScreen.update(screenSize);
            winScreen.update(screenSize);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            KeyboardState kState = Keyboard.GetState();

            switch (game1)
                {
                    case GameState.Menu:
                        if (kState.IsKeyDown(Keys.Space))
                        {
                            level1 = new Level();
                            level1.LoadContent(Content, GraphicsDevice);
                            updateScreenSize();
                            level1.playMusic();
                            game1 = GameState.Playing;
                        }
                        mainMenu.moveSword((float)gameTime.ElapsedGameTime.TotalSeconds);
                        if (mainMenu.HandleMouseClick())
                        {
                            game1 = GameState.Settings;
                        }
                    break;
                    case GameState.Settings:
                        settingsMenu.Update(kState);
                        if (kState.IsKeyDown(Keys.Enter))
                        {
                            mainMenu.playMusic();
                            game1 = GameState.Menu;
                        }
                        if (settingsMenu.isFullscreen)
                        {
                            screenSize = new Vector2(
                                GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width,
                                GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height - 70
                                );
                            _graphics.PreferredBackBufferWidth = (int)screenSize.X;
                            _graphics.PreferredBackBufferHeight = (int)screenSize.Y;
                            _graphics.ApplyChanges();
                            updateScreenSize();
                        }
                        else
                        {
                            screenSize = new Vector2(800, 480);   
                            _graphics.PreferredBackBufferWidth = (int)screenSize.X;
                            _graphics.PreferredBackBufferHeight = (int)screenSize.Y;
                            _graphics.ApplyChanges();
                            updateScreenSize();
                        }
                    break;
                    case GameState.Playing:
                        level1.Update(gameTime);
                        gui.Update(gameTime, screenSize, level1.score, level1.player.health);
                        if (level1.player.health <= 0 || !level1.player.isAlive)
                        {
                            game1 = GameState.GameOver;
                        }
                        else if (kState.IsKeyDown(Keys.P) && gamePauseKeyUp)
                        {
                            game1 = GameState.Pause;
                            gamePauseKeyUp = false;
                        }
                        if (level1.player.reachedEnd)
                        {
                            game1 = GameState.Win;
                        }
                    break;
                    case GameState.Pause:
                        if (kState.IsKeyDown(Keys.P) && gamePauseKeyUp)
                        {
                            MediaPlayer.Resume();
                            game1 = GameState.Playing;
                            gamePauseKeyUp = false;
                        }  
                    break;
                    case GameState.Win:
                        winScreen.Update(gameTime, level1.score);
                    if (kState.IsKeyDown(Keys.Enter) && game1 == GameState.Win)
                        {
                            winScreen.blackBoxSize = new Vector2(screenSize.X / 64, screenSize.Y / 64);
                            winScreen.played = false;
                            mainMenu.playMusic();
                            game1 = GameState.Menu;
                        }
                    break;
                    case GameState.GameOver:
                        level1.Update(gameTime);
                        if (kState.IsKeyDown(Keys.Enter) && game1 == GameState.GameOver)
                        {
                            level1 = new Level();
                            level1.LoadContent(Content, GraphicsDevice);
                            level1.playMusic();
                            updateScreenSize();
                            game1 = GameState.Playing;
                        }
                        else if (kState.IsKeyDown(Keys.Back))
                        {
                            mainMenu.playMusic();
                            game1 = GameState.Menu;
                        }
                    break;
                    default:
                        break;
                }

            if (!(game1 == GameState.Playing || game1 == GameState.Menu))
            {
                MediaPlayer.Pause();
            }

            if (kState.IsKeyUp(Keys.P))
            {
                gamePauseKeyUp = true;
            }

            SetVolume(settingsMenu.volumeLevel);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(20, 152, 220));

            _spriteBatch.Begin(samplerState: SamplerState.PointClamp);

            switch (game1)
            {
                case GameState.Menu:
                    mainMenu.draw(_spriteBatch);
                    break;
                case GameState.Settings:
                    settingsMenu.Draw(_spriteBatch);
                    break;
                case GameState.Playing:
                    level1.Draw(_spriteBatch);
                    gui.Draw(_spriteBatch);
                    //_spriteBatch.DrawString(font, $"{level1.player.Hitbox}", new Vector2(50, 70), Color.Gray);//debuging hitbox
                    break;
                case GameState.Pause:
                    level1.Draw(_spriteBatch);
                    gui.Draw(_spriteBatch);
                    pauseMenu.draw(_spriteBatch);
                    break;
                case GameState.Win:
                    level1.Draw(_spriteBatch);
                    winScreen.Draw(_spriteBatch);
                    break;
                case GameState.GameOver:
                    level1.Draw(_spriteBatch);
                    gui.Draw(_spriteBatch);
                    gameOverScreen.draw(_spriteBatch);
                    break;
                default:
                    break;
            }
            
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
