﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Hollow_Quest.Entities
{
    public class  Collectible : Entity
    {
        public bool collected = false;

        private int animationCounter = 0;
        private int animationFrame = 0;

        public SoundEffect coinSound;

        public Collectible(Texture2D spritesheet, Vector2 startPostion) : base(spritesheet, startPostion) { }

        public override void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            content.Load<Texture2D>("coin_spritesheet");
            coinSound = content.Load<SoundEffect>("coin");
        }

        public override void Update(GameTime gameTime)
        {
            Hitbox = new Rectangle(
                (int)Position.X,
                (int)Position.Y, 
                16, 16);

            HandleAnimations();
        }

        public override void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset)
        {
            if (!collected)
            {
                spriteBatch.Draw(spritesheet, new Rectangle(
                    (int)Position.X + (int)cameraOffset.X - 8, 
                    (int)Position.Y + (int)cameraOffset.Y - 8, 
                    32, 32), 
                    new Rectangle(animationFrame * 16, 0, 16, 16), 
                    Color.White);
            }  
        }

        private void HandleAnimations()
        {
            animationCounter++;
            if (animationCounter < 5)
            {
                animationFrame = 0;
            }
            else if (animationCounter < 10)
            {
                animationFrame = 1;
            }
            else if (animationCounter < 15)
            {
                animationFrame = 2;
            }
            else if (animationCounter < 20)
            {
                animationFrame = 3;
            }
            else if (animationCounter < 25)
            {
                animationFrame = 4;
            }
            else if (animationCounter < 30)
            {
                animationFrame = 5;
            }
            else if (animationCounter < 35)
            {
                animationFrame = 6;
            }
            else if (animationCounter < 40)
            {
                animationFrame = 7;
            }
            else if (animationCounter < 45)
            {
                animationFrame = 8;
            }
            else if (animationCounter < 50)
            {
                animationFrame = 9;
            }
            else if (animationCounter < 55)
            {
                animationFrame = 10;
            }
            else if (animationCounter < 60)
            {
                animationFrame = 11;
            }
            else
            {
                animationCounter = 0;
                animationFrame = 0;
            }
        }
    }
}
