﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
using MonoGame.Extended.Timers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using static System.Formats.Asn1.AsnWriter;

namespace Hollow_Quest.Entities
{
    public class Boss : Entity
    {
        public enum BossState
        {
            Idle,
            Attacking,
            Enraged,
            Fury,
            Dead
        } public BossState state;
        public enum BossAnimation
        {
            Idle,
            Walk,
            Attack,
            Hurt,
            Die
        } public BossAnimation animation;

        public int Health;
        public int speed;
        private Vector2 velocity;
        private Vector2 direction;
        private bool isFacingRight;

        public int animationFrame;
        public int animationCounter;
        private int animationSpeed;

        private Vector2 playerPosition;
        private double moveProbability;
        public Rectangle hurtbox;
        private bool fightStart;

        private Vector2 fireballSpawnPoint;
        private Texture2D fireballTexture;
        public List<Fireball> fireballs = new();
        private SoundEffect fireballSFX;

        private Song backgoundMusic;

        private readonly Random rand = new();

        public Boss(Texture2D spritesheet, Vector2 startPostion) : base(spritesheet, startPostion) { }

        public void Initialize() 
        {
            state = BossState.Idle;
            animation = BossAnimation.Idle;

            Health = 15;
            speed = 0;
            velocity = Vector2.Zero;
            direction = new Vector2(-1, 0);
            isFacingRight = false;

            animationFrame = 0;
            animationCounter = 0;
            animationSpeed = 1;

            playerPosition = Vector2.Zero;
            moveProbability = 0;
            hurtbox = new Rectangle(0, 0, 1, 1);
            fightStart = false;

            List<Fireball> fireballs = new();
        }

        public override void LoadContent(ContentManager content, GraphicsDevice graphicsDevice) 
        {
            fireballTexture = content.Load<Texture2D>("Enemies/fireball");
            fireballSFX = content.Load<SoundEffect>("SFX/fireball");
            backgoundMusic = content.Load<Song>("BGM/boss_fight");
        }

        public override void Update(GameTime gameTime) 
        {     
            HandlePhysics(gameTime);
            HandleFacingDirection();
            HandleStateChange();
            HandleState();
            HandleAnimations();
            HandleFireballs(gameTime);
        }

        public override void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset) 
        {
            SpriteEffects flip = !isFacingRight ? SpriteEffects.None : SpriteEffects.FlipHorizontally;

            spriteBatch.Draw(
                spritesheet, 
                new Vector2(
                (int)Position.X + (int)cameraOffset.X - 212,
                (int)Position.Y + (int)cameraOffset.Y - 180
                ),
                new Rectangle(288 * animationFrame, 160 * (int)animation, 288, 160),
                Color.White,
                0f,
                Vector2.Zero,
                2f,
                flip,
                0f);

            DrawFireballs(spriteBatch, cameraOffset);
        }

        private void HandlePhysics(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (Position.Y > 408) // Ground Collision
            {
                Position.Y = 408;
                velocity.Y = 0;
            }

            if (Position.X < 2240) // Boundaries
            {
                Position.X = 2240;
            }
            else if (Position.X > 2570)
            {
                Position.X = 2570;
            }

            if (velocity.X != 0) // Walking Animation when moving
            {
                if (animation != BossAnimation.Walk && animation != BossAnimation.Hurt)
                {
                    animationCounter = 0;
                    animationFrame = 0;
                    animation = BossAnimation.Walk;
                }  
            }

            velocity.Y += Gravity * dt;
            velocity.X = speed * direction.X;
            Position += velocity * dt;
        }

        private void HandleFacingDirection()
        {
            if (velocity.X > 0)
            {
                isFacingRight = true;
                Hitbox = new Rectangle((int)Position.X + 10, (int)Position.Y - 10, 125, 150);
            }
            else if (velocity.X < 0)
            {
                isFacingRight = false;
                Hitbox = new Rectangle((int)Position.X + 20, (int)Position.Y - 10, 125, 150);
            }
        }

        private void HandleStateChange()
        {
            if (Health <= 8 && Health > 3)
            {
                state = BossState.Enraged;
            }
            else if (Health <= 3 && Health > 0)
            {
                state = BossState.Fury;
            }
            else if (Health <= 0)
            {
                state = BossState.Dead;
            }
        }

        private void HandleState()
        {
            switch (state)
            {
                case BossState.Idle:
                    if (animation != BossAnimation.Idle)
                    {
                        animationCounter = 0;
                        animationFrame = 0;
                        speed = 0;
                        animation = BossAnimation.Idle;
                    }
                    break;
                case BossState.Attacking:
                    HandleBehaviour();
                    moveProbability = 0.1;
                    animationSpeed = 1; 
                    if (animation == BossAnimation.Walk)
                    {
                        speed = 50;
                    }

                    break;
                case BossState.Enraged:
                    HandleBehaviour();
                    animationSpeed = 2;
                    moveProbability = 0.3;
                    if (animation == BossAnimation.Walk)
                    {
                        speed = 80;
                    }
                    break;
                case BossState.Fury:
                    HandleBehaviour();
                    animationSpeed = 3;
                    moveProbability = 0.5;
                    if (animation == BossAnimation.Walk)
                    {
                        speed = 110;
                    }
                    break;
                case BossState.Dead:
                    animationSpeed = 1;
                    speed = 0;
                    hurtbox = new Rectangle(0, 0, 1, 1);
                    MediaPlayer.Stop();
                    if (animation != BossAnimation.Die)
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                        animation = BossAnimation.Die;
                    }
                    break;
                default:
                    break;
            }
        }

        private void HandleAnimations()
        {
            switch (animation)
            {
                case BossAnimation.Idle:
                    animationCounter++;
                    if (animationCounter < 10)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 20)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 40)
                    {
                        animationFrame = 4;
                    }
                    else if (animationCounter < 50)
                    {
                        animationFrame = 5;
                    }
                    else
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                    }
                    break;
                case BossAnimation.Walk:
                    animationCounter++;
                    if (animationCounter < 8 / animationSpeed)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 16 / animationSpeed)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 24 / animationSpeed)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 32 / animationSpeed)
                    {
                        animationFrame = 4;
                    }
                    else if (animationCounter < 40 / animationSpeed)
                    {
                        animationFrame = 5;
                    }
                    else if (animationCounter < 48 / animationSpeed)
                    {
                        animationFrame = 6;
                    }
                    else if (animationCounter < 56 / animationSpeed)
                    {
                        animationFrame = 7;
                    }
                    else if (animationCounter < 64 / animationSpeed)
                    {
                        animationFrame = 8;
                    }
                    else if (animationCounter < 72 / animationSpeed)
                    {
                        animationFrame = 9;
                    }
                    else if (animationCounter < 80 / animationSpeed)
                    {
                        animationFrame = 10;
                    }
                    else if (animationCounter < 88 / animationSpeed)
                    {
                        animationFrame = 11;
                    }
                    else
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                    }
                    break;
                case BossAnimation.Attack:
                    animationCounter++;
                    if (animationCounter < 10 / animationSpeed)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 20 / animationSpeed)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 30 / animationSpeed)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 40 / animationSpeed)
                    {
                        animationFrame = 4;
                    }
                    else if (animationCounter < 50 / animationSpeed)
                    {
                        animationFrame = 5;
                    }
                    else if (animationCounter < 60 / animationSpeed)
                    {
                        animationFrame = 6;
                    }
                    else if (animationCounter < 70 / animationSpeed)
                    {
                        animationFrame = 7;
                    }
                    else if (animationCounter < 80 / animationSpeed)
                    {
                        animationFrame = 8;
                    }
                    else if (animationCounter < 90 / animationSpeed)
                    {
                        animationFrame = 9;
                    }
                    else if (animationCounter < 100 / animationSpeed)
                    {
                        animationFrame = 10;
                    }
                    else if (animationCounter < 110 / animationSpeed)
                    {
                        animationFrame = 11;
                    }
                    else if (animationCounter < 120 / animationSpeed)
                    {
                        animationFrame = 12;
                    }
                    else if (animationCounter < 130 / animationSpeed)
                    {
                        animationFrame = 13;
                    }
                    else if (animationCounter < 140 / animationSpeed)
                    {
                        animationFrame = 14;
                    }
                    else
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                    }
                    break;
                case BossAnimation.Hurt:
                    animationCounter++;
                    if (animationCounter < 10)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 20)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 40)
                    {
                        animationFrame = 4;
                    }
                    break;
                case BossAnimation.Die:
                    animationCounter++;
                    if (animationCounter < 10)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 20)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 40)
                    {
                        animationFrame = 4;
                    }
                    else if (animationCounter < 50)
                    {
                        animationFrame = 5;
                    }
                    else if (animationCounter < 60)
                    {
                        animationFrame = 6;
                    }
                    else if (animationCounter < 70)
                    {
                        animationFrame = 7;
                    }
                    else if (animationCounter < 80)
                    {
                        animationFrame = 8;
                    }
                    else if (animationCounter < 90)
                    {
                        animationFrame = 9;
                    }
                    else if (animationCounter < 100)
                    {
                        animationFrame = 10;
                    }
                    else if (animationCounter < 110)
                    {
                        animationFrame = 11;
                    }
                    else if (animationCounter < 120)
                    {
                        animationFrame = 12;
                    }
                    else if (animationCounter < 130)
                    {
                        animationFrame = 13;
                    }
                    else if (animationCounter < 140)
                    {
                        animationFrame = 14;
                    }
                    else if (animationCounter < 150)
                    {
                        animationFrame = 15;
                    }
                    else if (animationCounter < 160)
                    {
                        animationFrame = 16;
                    }
                    else if (animationCounter < 170)
                    {
                        animationFrame = 17;
                    }
                    else if (animationCounter < 180)
                    {
                        animationFrame = 18;
                    }
                    else if (animationCounter < 190)
                    {
                        animationFrame = 19;
                    }
                    else if (animationCounter < 200)
                    {
                        animationFrame = 20;
                    }
                    else if (animationCounter < 210)
                    {
                        animationFrame = 21;
                    }
                    break;
                default:
                    break;
            }

            if (animation == BossAnimation.Hurt && animationFrame == 4) // Hurt animation finished
            {
                animation = BossAnimation.Walk;
            }

        }

        private void HandleFireballs(GameTime gameTime)
        {
            fireballSpawnPoint = new Vector2(Hitbox.Center.X, Hitbox.Center.Y - 20);

            if (fireballs != null)
            {
                foreach (Fireball fireball in fireballs)
                {
                    fireball.updatePlayerPosition(playerPosition);
                    fireball.Update(gameTime);
                }
                fireballs.RemoveAll(f => f.isOutOfBounds);
            }
        }

        private void HandleBehaviour()
        {
            double chance = rand.NextDouble();

            if (chance < moveProbability)
            {
                FollowPlayer();
            }

            if (animation == BossAnimation.Attack && animationFrame == 14) // Finish attack animation before moving
            {
                animationFrame = 0;
                animationCounter = 0;
                animation = BossAnimation.Walk;
            }

            if (playerPosition.Y > Hitbox.Top)
            {
                HandleAttackLogic();
            }
            else
            {
                HandleFireballLogic();
            }
        }

        private void FollowPlayer()
        {
            if (playerPosition.X - 30 < Hitbox.Left) // Player to the left
            {
                direction = new Vector2(-1, 0);
                if (animation == BossAnimation.Idle && isFacingRight)
                {
                    isFacingRight = false;
                }
            }
            else if (playerPosition.X > Hitbox.Right) //Player to the right
            {
                direction = new Vector2(1, 0);
                if (animation == BossAnimation.Idle && !isFacingRight)
                {
                    isFacingRight = true;
                }
            }
        }

        private void HandleAttackLogic()
        {
            if (animation != BossAnimation.Walk && animation != BossAnimation.Attack) // Reset to walk animation
            {
                animationFrame = 0;
                animationCounter = 0;
                animation = BossAnimation.Walk;
            }

            if (playerPosition.X + 15 < Hitbox.Center.X && playerPosition.X + 15 > Hitbox.Center.X - 200) // Player in attack range to the left
            {
                speed = 0;
                isFacingRight = false;
                if (animation != BossAnimation.Attack) // Start attack animation
                {
                    animationFrame = 0;
                    animationCounter = 0;
                    animation = BossAnimation.Attack;
                }
                if (animationFrame >= 9 && animationFrame <= 11) // Create hurtbox at attack frames
                {
                    hurtbox = new Rectangle((int)Position.X - 160, (int)Position.Y + 80, 130, 50);
                }
                else
                {
                    hurtbox = new Rectangle(0, 0, 1, 1); // No hurtbox
                }
            }
            else if (playerPosition.X + 15 > Hitbox.Center.X && playerPosition.X + 15 < Hitbox.Center.X + 200) // Player in attack range to the right
            {
                speed = 0;
                isFacingRight = true;
                if (animation != BossAnimation.Attack) // Start attack animation
                {
                    animationFrame = 0;
                    animationCounter = 0;
                    animation = BossAnimation.Attack;
                }
                if (animationFrame >= 9 && animationFrame <= 11) // Create hurtbox at attack frames
                {
                    hurtbox = new Rectangle((int)Position.X + 180, (int)Position.Y + 80, 130, 50);
                }
                else
                {
                    hurtbox = new Rectangle(0, 0, 1, 1); // No hurtbox
                }
            }
            else if (!(animationFrame >= 9 && animationFrame <= 11)) // Player out of attack range, no hurtbox
            {
                hurtbox = new Rectangle(0, 0, 1, 1);
            }
        }

        private void HandleFireballLogic()
        {
            double chance = rand.NextDouble();

            if (animation != BossAnimation.Idle && animation != BossAnimation.Hurt && state != BossState.Dead) // Reset to idle animation when not attacking
            {
                speed = 0;
                animationFrame = 0;
                animationCounter = 0;
                animation = BossAnimation.Idle;
            }

            if (chance < moveProbability / 25 && state != BossState.Dead) // Fireball chance
            {
                fireballs.Add(new Fireball(fireballTexture, new Vector2(fireballSpawnPoint.X, fireballSpawnPoint.Y)));
                fireballSFX.Play();
            }
        }

        private void DrawFireballs(SpriteBatch spriteBatch, Vector2 cameraOffset)
        {
            if (fireballs != null)
            {
                foreach (Fireball fireball in fireballs)
                {
                    fireball.Draw(spriteBatch, cameraOffset);
                }
            }
        }

        public void HandleStartFight()
        {
            if (playerPosition.X > 1980 && playerPosition.Y < 530) // Player entered boss area
            {
                if (state == BossState.Idle && !fightStart)
                {
                    state = BossState.Attacking;
                    speed = 50;
                    animation = BossAnimation.Walk;
                    MediaPlayer.Stop();
                    MediaPlayer.Play(backgoundMusic);
                    fightStart = true;
                }
            }
        }

        public void GetPlayerPosition(Vector2 playerPostion)
        {
            this.playerPosition = playerPostion;
        }
    }
}
