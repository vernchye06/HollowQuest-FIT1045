﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Hollow_Quest.Entities
{
    public abstract class Entity
    {
        public Vector2 Position;
        public Rectangle Hitbox;
        protected const float Gravity = 900f;
        
        public Texture2D spritesheet;

        public Entity(Texture2D spritesheet, Vector2 startPosition)
        {
            this.spritesheet = spritesheet;
            this.Position = startPosition;
        }
        public virtual void LoadContent(ContentManager content, GraphicsDevice graphicsDevice) { }
        public virtual void Update(GameTime gameTime) { }
        public virtual void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset) { }
    }
}
