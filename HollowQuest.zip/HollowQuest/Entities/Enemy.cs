﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Diagnostics;

namespace Hollow_Quest.Entities
{
    public class Enemy : Entity
    {
        public float speed = 50f;
        private Vector2 velocity;
        private Vector2 direction;

        private bool isFacingRight;
        public bool touchedPlayer;

        public int animationCounter;
        private int animationFrame;
        public int spritesheetRow;

        public Enemy(Texture2D spritesheet, Vector2 startPostion) : base(spritesheet, startPostion) { }

        public void Initialize()
        {
            velocity = Vector2.Zero;
            direction = new Vector2(-1, 0);

            isFacingRight = true;
            touchedPlayer = false;

            animationCounter = 0;
            animationFrame = 0;
            spritesheetRow = 0;
        }

        public override void Update(GameTime gameTime)
        {
            HandlePhysics(gameTime);
            HandleFacingDirection();
            HandleAnimations();
        }

        public override void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset)
        {
            SpriteEffects flip = isFacingRight ? SpriteEffects.None : SpriteEffects.FlipHorizontally;

            spriteBatch.Draw(
                spritesheet, 
                new Vector2(
                (int)Position.X + (int)cameraOffset.X - 12, 
                (int)Position.Y + (int)cameraOffset.Y - 24
                ), 
                new Rectangle(animationFrame * 24, spritesheetRow, 24, 24), 
                Color.White,
                0f,
                Vector2.Zero,
                2f,
                flip,
                0f);
        }

        private void HandlePhysics(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            velocity.Y += Gravity * dt;
            velocity.X = speed * direction.X;
            Position += velocity * dt;

            Hitbox = new Rectangle((int)Position.X, (int)Position.Y, 24, 24);
        }

        private void HandleFacingDirection()
        {
            if (velocity.X > 0)
            {
                isFacingRight = true;
            }
            else if (velocity.X < 0)
            {
                isFacingRight = false;
            }
        }

        private void HandleAnimations()
        {
            animationCounter++;
            if (animationCounter < 15)
            {
                animationFrame = 1;
            }
            else if (animationCounter < 30)
            {
                animationFrame = 2;
            }
            else if (animationCounter < 45)
            {
                animationFrame = 3;
            }
            else
            {
                animationFrame = 0;
                animationCounter = 0;
            }
        }

        public void HandleRedCollision(Rectangle tile)
        {
            if (Hitbox.Intersects(tile))
            {
                if (Hitbox.Right > tile.Left && Hitbox.Right < tile.Right) // Intersect left
                {
                    Position.X = tile.Left - 23;
                    direction.X *= -1;
                }
                else if (Hitbox.Left < tile.Right && Hitbox.Left > tile.Left) // Intersect right
                {
                    Position.X = tile.Right + 1;
                    direction.X *= -1;
                }
                velocity.X = 0;
            }
        }

        public void HandleYellowCollision(Rectangle tile)
        {
            if (Hitbox.Intersects(tile))
            {
                Rectangle intersection = Rectangle.Intersect(Hitbox, tile);
                if (intersection.Height > intersection.Width) // Intersect horizontally
                {
                    if (Hitbox.Right > tile.Left && Hitbox.Right < tile.Right)
                    {
                        Position.X = tile.Left - 23;
                        direction.X *= -1;
                    }
                    else if (Hitbox.Left < tile.Right && Hitbox.Left > tile.Left)
                    {
                        Position.X = tile.Right + 1;
                        direction.X *= -1;
                    }
                    velocity.X = 0;
                }
                else // Intersect vertically
                {
                    if (Hitbox.Top < tile.Bottom && Hitbox.Top > tile.Top)
                    {
                        Position.Y = tile.Bottom;
                    }
                    else if (Hitbox.Bottom > tile.Top && Hitbox.Bottom < tile.Bottom)
                    {
                        Position.Y = tile.Top - 23;
                    }
                    velocity.Y = 0;
                }
            }
        }
    }
}
