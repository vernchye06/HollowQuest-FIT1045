﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.Animations;
using MonoGame.Extended.Content.Tiled;
using System.ComponentModel.Design;
using System.Diagnostics;

namespace Hollow_Quest.Entities
{
    public class Player : Entity
    {
        public enum PlayerAnimation
        {
            Idle,
            Running,
            Rolling,
            Hurt,
            Die
        } public PlayerAnimation animation;

        private SoundEffect jumpSound;
        public SoundEffect attackSound;
        public SoundEffect hurtSound;

        public Vector2 velocity;
        private const float speed = 150f;
        public float jumpStrength = 300f;
        public int health;
        public int invincibilityFrames;

        private bool isOnGround;
        private bool isFacingRight;
        public bool isAlive;
        public bool isHurt;
        private bool isFalling;
        public bool reachedEnd;
        public bool bossDefeated;

        public int animationCounter;
        public int animationFrame;
        public int spritesheetRow;
        
        public bool canDoubleJump;
        private int doubleJumpCD;
        private bool performDoubleJump;
        private bool spaceKeyRealeased;

        public bool canWallJump;
        private bool isTouchingWall;
        private int wallJumpCD;

        public bool canRoll;
        private int rollCD;
        private int rollDisplacement;
        public Rectangle rollHitBox;

        public Player(Texture2D spritesheet, Vector2 startPostion) : base(spritesheet, startPostion) { }

        public void Initialize()
        {
            velocity = Vector2.Zero;
            health = 5;
            invincibilityFrames = 60;

            isOnGround = false;
            isFacingRight = true;
            isAlive = true;
            isHurt = false;
            isFalling = true;
            reachedEnd = false;
            bossDefeated = false;

            animationCounter = 0;
            animationFrame = 0;
            spritesheetRow = 0;
            animation = PlayerAnimation.Idle;

            canDoubleJump = false;
            doubleJumpCD = 0;
            performDoubleJump = false;
            spaceKeyRealeased = true;

            canWallJump = false;
            isTouchingWall = false;
            wallJumpCD = 0;

            canRoll = false;
            rollCD = 0;
            rollDisplacement = 0;
            rollHitBox = new Rectangle ((int)Position.X + Hitbox.Width, (int)Position.Y, Hitbox.Width * 3, Hitbox.Height);
        }

        public override void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            jumpSound = content.Load<SoundEffect>("SFX/jump");
            attackSound = content.Load<SoundEffect>("SFX/tap");
            hurtSound = content.Load<SoundEffect>("SFX/hurt");
        }

        public override void Update(GameTime gameTime)
        {
            HandleDeath();
            HandlePhysics(gameTime);
            HandleFacingDirection();
            HandleInvincibility();
            HandleCD();
            HandleRollHitBox();
            HandleAnimations();  
        }

        public override void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset)
        {
            SpriteEffects flip = isFacingRight ? SpriteEffects.None : SpriteEffects.FlipHorizontally;

            spriteBatch.Draw(
                spritesheet,
                new Vector2(
                (int)Position.X + (int)cameraOffset.X - 16,
                (int)Position.Y + (int)cameraOffset.Y - 24
                ),
                new Rectangle(animationFrame * 32, spritesheetRow * 32, 32, 32),
                Color.White,
                0f,
                Vector2.Zero,
                2f,
                flip,
                0f);
        }

        private void HandleDeath()
        {
            if (isAlive)
            {
                HandleInput();
            }
            else
            {
                velocity = Vector2.Zero;
                animation = PlayerAnimation.Die;
            }
        }

        private void HandlePhysics(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (isFalling || !isOnGround) // Apply gravity
            {
                velocity.Y += Gravity * dt;
            }
            Position += velocity * dt;
            Hitbox = new Rectangle((int)Position.X, (int)Position.Y, 30, 30);

            if (Position.Y > 1800) // Fell off the level
            {
                health = 0;
            }
            if (Position.X > 3360 && bossDefeated) // Reached the end of the level
            {
                reachedEnd = true;
            }
        }

        private void HandleFacingDirection()
        {
            if (velocity.X > 0)
            {
                isFacingRight = true;
                if (rollDisplacement < 0) // Adjust roll displacement direction
                {
                    rollDisplacement *= -1;
                }
            }
            else if (velocity.X < 0)
            {
                isFacingRight = false;
                if (rollDisplacement > 0) // Adjust roll displacement direction
                {
                    rollDisplacement *= -1;
                }
            }
        }

        private void HandleInvincibility()
        {
            if (isHurt) // If the player is hurt, decrease invincibility frames
            {
                invincibilityFrames--;
                if (invincibilityFrames <= 0) // When invincibility frames are over
                {
                    isHurt = false;
                    if (animation != PlayerAnimation.Die)
                    {
                        animationCounter = 0;
                        animationFrame = 0;
                        animation = PlayerAnimation.Idle;
                    }
                    invincibilityFrames = 60; // Reset invincibility frames
                }
            }
        }

        private void HandleCD()
        {
            // Reduce cooldowns for abilities
            if (doubleJumpCD > 0)
            {
                doubleJumpCD--;
            }
            if (isOnGround)
            {
                performDoubleJump = false;
            }

            if (wallJumpCD > 0)
            {
                wallJumpCD--;
            }

            if (rollCD > 0)
            {
                rollCD--;
            }
        }

        private void HandleRollHitBox()
        {
            // Update roll hitbox position based on facing direction
            if (isFacingRight)
            {
                rollHitBox = new Rectangle((int)Position.X + Hitbox.Width, (int)Position.Y - 1, Hitbox.Width * 3, Hitbox.Height - 2);
            }
            else
            {
                rollHitBox = new Rectangle((int)Position.X - Hitbox.Width * 3, (int)Position.Y - 1, Hitbox.Width * 3, Hitbox.Height - 2);
            }
        }

        private void HandleAnimations()
        {
            switch (animation)
            {
                case PlayerAnimation.Idle:
                    spritesheetRow = 0;
                    animationCounter++;
                    if (animationCounter < 15)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 45)
                    {
                        animationFrame = 3;
                    }
                    else
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                    }
                    break;
                case PlayerAnimation.Running:
                    spritesheetRow = 2;
                    animationCounter++;
                    if (animationCounter < 15)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 45)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 60)
                    {
                        animationFrame = 4;
                    }
                    else if (animationCounter < 75)
                    {
                        animationFrame = 5;
                    }
                    else if (animationCounter < 90)
                    {
                        animationFrame = 6;
                    }
                    else if (animationCounter < 105)
                    {
                        animationFrame = 7;
                    }
                    else
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                    }
                    break;
                case PlayerAnimation.Rolling:
                    spritesheetRow = 5;
                    animationCounter++;
                    if (animationCounter < 5)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 10)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 15)
                    {
                        animationFrame = 3;
                    }
                    else if (animationCounter < 20)
                    {
                        animationFrame = 4;
                    }
                    else if (animationCounter < 25)
                    {
                        animationFrame = 5;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 6;
                    }
                    else if (animationCounter < 35)
                    {
                        animationFrame = 7;
                    }
                    else
                    {
                        animationFrame = 0;
                        animationCounter = 0;
                        animation = PlayerAnimation.Idle;
                    }
                    break;
                case PlayerAnimation.Hurt:
                    spritesheetRow = 6;
                    animationCounter++;
                    if (animationCounter < 15)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 45)
                    {
                        animationFrame = 3;
                    }
                    break;
                case PlayerAnimation.Die:
                    spritesheetRow = 7;
                    animationCounter++;
                    if (animationCounter < 15)
                    {
                        animationFrame = 1;
                    }
                    else if (animationCounter < 30)
                    {
                        animationFrame = 2;
                    }
                    else if (animationCounter < 45)
                    {
                        animationFrame = 3;
                    }
                    break;
                default:
                    break;
            }

        }

        private void HandleInput()
        {
            KeyboardState keyboardState = Keyboard.GetState();

            // Horizontal movement
            if (keyboardState.IsKeyDown(Keys.A))
            {
                velocity.X = -speed;
                if (animation != PlayerAnimation.Hurt && animation != PlayerAnimation.Rolling && !isHurt)
                {
                    animation = PlayerAnimation.Running;
                }
            }
            else if (keyboardState.IsKeyDown(Keys.D))
            {
                velocity.X = speed;
                if (animation != PlayerAnimation.Hurt && animation != PlayerAnimation.Rolling && !isHurt)
                {
                    animation = PlayerAnimation.Running;
                }
            }
            else
            {
                velocity.X = 0;
                if (animation != PlayerAnimation.Hurt && animation != PlayerAnimation.Rolling && !isHurt)
                {
                    animation = PlayerAnimation.Idle;
                }
            }

            // Jumping
            if (keyboardState.IsKeyDown(Keys.Space) && isOnGround)
            {
                velocity.Y = -jumpStrength;
                jumpSound?.Play();
                isOnGround = false;
                spaceKeyRealeased = false;
            }

            // Rolling
            if (keyboardState.IsKeyDown(Keys.H) && canRoll && isOnGround)
            {
                HandleRoll();

            }

            // Wall Jumping
            if (keyboardState.IsKeyDown(Keys.Space) && canWallJump)
            {
                HandleWallJump();
            }

            // Double Jumping
            if (keyboardState.IsKeyDown(Keys.Space) && spaceKeyRealeased && canDoubleJump)
            {
                spaceKeyRealeased = false;
                HandleDoubleJump();
            }

            if (keyboardState.IsKeyUp(Keys.Space))
            {
                spaceKeyRealeased = true;
            }
        }

        private void HandleRoll()
        {
            if (rollCD > 0) // Roll is on cooldown
            {
                return;
            }
            Position.X += rollDisplacement; // Move player by roll displacement
            rollCD = 60;
            animationCounter = 0;
            animationFrame = 0;
            animation = PlayerAnimation.Rolling;
        }

        private void HandleWallJump()
        {
            if (wallJumpCD > 0) // Wall jump is on cooldown
            {
                return;
            }
            if (isTouchingWall && !isOnGround) // Player is touching a wall and not on the ground
            {
                velocity.Y = -jumpStrength;
                jumpSound?.Play();
                wallJumpCD = 5;
            }
        }

        private void HandleDoubleJump()
        {
            if (doubleJumpCD > 0 || performDoubleJump) // Double jump is on cooldown or already performed
            {
                return;
            }
            if (!isOnGround || isFalling && !isTouchingWall) // Player is in the air and not touching a wall
            {
                velocity.Y = -jumpStrength;
                jumpSound?.Play();
                performDoubleJump = true;
                doubleJumpCD = 30;
            }
        }

        public void HandleRedCollision(Rectangle tile)
        {
            if (Hitbox.Intersects(tile))
            {
                if (Hitbox.Right > tile.Left && Hitbox.Right < tile.Right)
                {
                    Position.X = tile.Left - 30;
                }
                else if (Hitbox.Left < tile.Right && Hitbox.Left > tile.Left)
                {
                    Position.X = tile.Right + 1;
                }
                velocity.X = 0;
            }
        }

        public void HandleBlueCollision(Rectangle tile)
        {
            if (Hitbox.Intersects(tile))
            {
                if (Hitbox.Right > tile.Left && Hitbox.Right < tile.Right)
                {
                    Position.X = tile.Left - 28;
                }
                else if (Hitbox.Left < tile.Right && Hitbox.Left > tile.Left)
                {
                    Position.X = tile.Right - 2;
                }
                velocity.X = 0;
                isTouchingWall = true;
                
            }
            else
            {
                isTouchingWall = false;
            }
        }

        public void HandleYellowCollision(Rectangle tile)
        {
            if (Hitbox.Intersects(tile))
            {
                Rectangle intersection = Rectangle.Intersect(Hitbox, tile);
                if (intersection.Height > intersection.Width)
                {
                    if (Hitbox.Right > tile.Left && Hitbox.Right < tile.Right)
                    {
                        Position.X = tile.Left - 30;
                    }
                    else if (Hitbox.Left < tile.Right && Hitbox.Left > tile.Left)
                    {
                        Position.X = tile.Right + 1;
                    }
                    velocity.X = 0;
                }
                else
                {
                    if (Hitbox.Top < tile.Bottom && Hitbox.Top > tile.Top)
                    {
                        Position.Y = tile.Bottom;
                    }
                    else if (Hitbox.Bottom > tile.Top && Hitbox.Bottom < tile.Bottom)
                    {
                        Position.Y = tile.Top - 29;
                        isOnGround = true;
                    }
                    velocity.Y = 0;
                }
            }
            else
            {
                isFalling = true;
            }
        }

        public void GetRollDisplacement(Rectangle tile)
        {
            if (tile.Intersects(rollHitBox))
            {
                if (isFacingRight)
                {
                    rollDisplacement = tile.Left - Hitbox.Right;
                }
                else
                {
                    rollDisplacement = tile.Right - Hitbox.Left;
                }
            }
        }
    }
}
