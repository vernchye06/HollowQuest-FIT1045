﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.ComponentModel.Design;

namespace Hollow_Quest.Entities
{
    public class Player : Entity
    {
        private float speed = 150f;
        public float jumpStrength = 300f;
        private bool isOnGround = false;
        public Vector2 velocity;

        public int animationCounter = 0;
        public int animationFrame = 0;
        private bool isFacingRight = true;
        public int spritesheetRow = 0;

        public int health = 5;
        public bool isAlive = true;
        public bool isHurt = false;
        public int invinsibilityFrames = 60;
        private bool isFalling = true;
        public bool reachedEnd = false;

        private SoundEffect jumpSound;
        public SoundEffect attackSound;
        public SoundEffect hurtSound;

        public Player(Texture2D spritesheet, Vector2 startPostion) : base(spritesheet, startPostion) { }

        public override void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            content.Load<Texture2D>("player_spritesheet");
            jumpSound = content.Load<SoundEffect>("jump");
            attackSound = content.Load<SoundEffect>("tap");
            hurtSound = content.Load<SoundEffect>("hurt");
        }

        public override void Update(GameTime gameTime)
        {
            if (isAlive)
            {
                HandleInput(gameTime);
            }
            else
            {
                velocity = Vector2.Zero;
            }

            HandlePhysics(gameTime);     

            if (velocity.X > 0)
            {
                isFacingRight = true;
            }
            else if (velocity.X < 0)
            {
                isFacingRight = false;
            }
            HandleInvincibility();

            HandleAnimations();
        }

        public override void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset)
        {
            SpriteEffects flip = isFacingRight ? SpriteEffects.None : SpriteEffects.FlipHorizontally;

            spriteBatch.Draw(
                spritesheet, 
                new Vector2(
                (int)Position.X + (int)cameraOffset.X - 16, 
                (int)Position.Y + (int)cameraOffset.Y - 24
                ), 
                new Rectangle(animationFrame * 32, spritesheetRow, 32, 32), 
                Color.White,
                0f,
                Vector2.Zero,
                2f,
                flip,
                0f);
        }

        private void HandleInput(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            if (keyboardState.IsKeyDown(Keys.A))
            {
                velocity.X = -speed;
            }
            else if (keyboardState.IsKeyDown(Keys.D))
            {
                velocity.X = speed;
            }
            else
            {
                velocity.X = 0;
            }

            if (keyboardState.IsKeyDown(Keys.Space) && isOnGround)
            {
                velocity.Y = -jumpStrength;
                jumpSound?.Play();
                isOnGround = false;
            }
        }

        private void HandlePhysics(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (isFalling)
            {
                velocity.Y += Gravity * dt;
            }
            Position += velocity * dt;
            Hitbox = new Rectangle((int)Position.X, (int)Position.Y, 30, 30);

            if (Position.Y > 1800) // Fell off the level
            {
                health = 0;
            }
            if (Position.X > 3296) // Reached the end of the level
            {
                reachedEnd = true;
            }
        }

        private void HandleAnimations()
        {
            animationCounter++;
            if (animationCounter < 15)
            {
                animationFrame = 1;
            }
            else if (animationCounter < 30)
            {
                animationFrame = 2;
            }
            else if (animationCounter < 45)
            {
                animationFrame = 3;
            }
            else
            {
                animationFrame = 0;
                animationCounter = 0;
            }
        }

        private void HandleInvincibility()
        {
            if (isHurt)
            {
                invinsibilityFrames--;
                if (invinsibilityFrames <= 0)
                {
                    isHurt = false;
                    invinsibilityFrames = 60;
                }
            }
        }

        public void HandleCollision(Rectangle tile)
        {
            if(Hitbox.Intersects(tile))
            {
                Rectangle intersection = Rectangle.Intersect(Hitbox, tile);
                if (intersection.Height > intersection.Width)
                {
                    if (Hitbox.Right > tile.Left && Hitbox.Right < tile.Right)
                    {
                        Position.X = tile.Left - 31;
                    }
                    else if (Hitbox.Left < tile.Right && Hitbox.Left > tile.Left)
                    {
                        Position.X = tile.Right + 1;
                    }
                    velocity.X = 0;
                }
                else
                {
                    if (Hitbox.Top < tile.Bottom && Hitbox.Top > tile.Top)
                    {
                        Position.Y = tile.Bottom;
                    }
                    else if (Hitbox.Bottom > tile.Top && Hitbox.Bottom < tile.Bottom)
                    {
                        Position.Y = tile.Top - 29;
                        isOnGround = true;
                    }
                    velocity.Y = 0;
                }
            }
            else
            {
                isFalling = true;
            }
        }
    }
}
