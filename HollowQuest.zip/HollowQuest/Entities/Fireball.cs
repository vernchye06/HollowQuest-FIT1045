﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Animations;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hollow_Quest.Entities
{
    public class Fireball : Entity
    {
        private int animationFrame = 0;
        private int animationCounter = 0;
        private float animationRotation = 0;

        private Vector2 direction = Vector2.Zero;
        private const float speed = 150f;
        public bool isOutOfBounds = false;

        private Vector2 playerPosition = Vector2.Zero;

        public Fireball(Texture2D spritesheet, Vector2 startPostion) : base(spritesheet, startPostion) { }

        public override void Update(GameTime gameTime) 
        {
            if (direction == Vector2.Zero)
            {
                getDirection();
            }
            HandleMovement(gameTime);
            updateHitbox();
            HandleAnimations();
            checkBounds();
        }

        public override void Draw(SpriteBatch spriteBatch, Vector2 cameraOffset) 
        {
            spriteBatch.Draw(
                spritesheet,
                new Vector2(
                (int)Position.X + (int)cameraOffset.X,
                (int)Position.Y + (int)cameraOffset.Y
                ),
                new Rectangle(animationFrame * 32, 0, 32, 32),
                Color.White,
                animationRotation,
                Vector2.Zero,
                2f,
                0f,
                0f);
        }

        private void getDirection()
        {
            direction = Vector2.Normalize(playerPosition - Position); // Get direction towards player

            if (direction.X < 0) // Adjust rotation based on direction
            {
                animationRotation = (float)(Math.Atan(direction.Y / direction.X) + Math.PI);
            }
            else
            {
                animationRotation = (float)(Math.Atan(direction.Y / direction.X));
            }
        }

        private void HandleMovement(GameTime gameTime)
        {
            Vector2 velocity = direction * speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            Position += velocity;
        }

        private void updateHitbox()
        {
            if (direction.X < 0)
            {
                Hitbox = new Rectangle((int)Position.X - 50, (int)Position.Y - 55, 35, 35);
            }
            else
            {
                Hitbox = new Rectangle((int)Position.X + 35, (int)Position.Y - 10, 35, 35);
            }
        }

        private void HandleAnimations()
        {
            animationCounter++;
            if (animationCounter < 8)
            {
                animationFrame = 1;
            }
            else if (animationCounter < 16)
            {
                animationFrame = 2;
            }
            else if (animationCounter < 24)
            {
                animationFrame = 3;
            }
            else
            {
                animationFrame = 0;
                animationCounter = 0;
            }
        }

        private void checkBounds()
        {
            if (Position.X < 0 || Position.X > 4000)
            {
                isOutOfBounds = true;
            }
        }

        public void updatePlayerPosition(Vector2 playerPos)
        {
            playerPosition = playerPos;
        }
    }
}
