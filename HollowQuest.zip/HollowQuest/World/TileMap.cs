﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;


namespace Hollow_Quest.World
{
    public class TileMap
    {
        public Dictionary<Vector2, int> tilemap;

        public const int TILESIZE = 32;
        public const int SRCTILESIZE = 16;

        public Dictionary<Vector2, int> LoadMap(string mapPath)
        {
            // Store each tile position and ID
            Dictionary<Vector2, int> result = new();

            StreamReader reader = new(mapPath);

            int y = 0;
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                string[] items = line.Split(','); // Stores CSV numbers removing the comma

                for (int x = 0; x < items.Length; x++)
                {
                    if (int.TryParse(items[x], out int tileIndex)) // Converts into integers
                    {
                        if (tileIndex >= 0) // If not an empty tile
                        {
                            result[new Vector2(x, y)] = tileIndex; // Add it to the Dictionary
                        }
                    }
                }

                y++;
            }
            return result;
        }

        public void Draw(SpriteBatch spriteBatch, Texture2D textureAtlas, Vector2 cameraOffset, List<Rectangle> textureStore)
        {
            foreach (var item in tilemap)
            {
                Rectangle dest = new // The tile location
                    (
                    (int)item.Key.X * TILESIZE + (int)cameraOffset.X,
                    (int)item.Key.Y * TILESIZE + (int)cameraOffset.Y, 
                    TILESIZE, 
                    TILESIZE
                    );

                Rectangle src = textureStore[item.Value]; // The tile image location in the texture atlas

                spriteBatch.Draw(textureAtlas, dest, src, Color.White);
            }   
        }
    }
}
