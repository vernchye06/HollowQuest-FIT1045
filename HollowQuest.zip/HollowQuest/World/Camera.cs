﻿using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Hollow_Quest.World
{
    public class Camera
    {
        public Vector2 Position;
        private Vector2 screenSize;

        public Camera(Vector2 Position, Vector2 screenSize)
        {
            this.Position = Position;
            this.screenSize = screenSize;
        }

        public void Update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
        }

        public void Follow(Rectangle target)
        {
            Position = new Vector2(
                -target.X + (screenSize.X / 2) + -(target.Width / 2),
                -target.Y + (screenSize.Y * 2 / 3) - (target.Height / 2)
                );
        }
    }
}
