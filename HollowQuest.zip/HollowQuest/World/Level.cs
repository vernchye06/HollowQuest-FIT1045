﻿using Hollow_Quest.Entities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using MonoGame.Extended.Tiled;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;

namespace Hollow_Quest.World
{
    public class Level
    {
        public Player player;
        private List<Enemy> enemies = new List<Enemy>();
        private List<Collectible> coins = new List<Collectible>();

        private Texture2D textureAtlas;
        private TileMap fg = new TileMap();
        private TileMap mg = new TileMap();
        private TileMap bg = new TileMap();

        private Texture2D collisionMap;
        private TileMap collision = new TileMap();

        private Song bgMusic;

        private Camera camera = new Camera(Vector2.Zero, new Vector2(800, 480));

        public int score = 0;

        private Vector2 screenSize;

        private List<Rectangle> tileMapTextureStore = new()
        {
            new Rectangle(0, 0, 16, 16),
            new Rectangle(16, 0, 16, 16),
            new Rectangle(32, 0, 16, 16),
            new Rectangle(48, 0, 16, 16),
            new Rectangle(64, 0, 16, 16),
            new Rectangle(80, 0, 16, 16),
            new Rectangle(96, 0, 16, 16),
            new Rectangle(112, 0, 16, 16),
            new Rectangle(128, 0, 16, 16),
            new Rectangle(144, 0, 16, 16),
            new Rectangle(160, 0, 16, 16),
            new Rectangle(176, 0, 16, 16),
            new Rectangle(192, 0, 16, 16),
            new Rectangle(208, 0, 16, 16),
            new Rectangle(224, 0, 16, 16),
            new Rectangle(240, 0, 16, 16),
            new Rectangle(0, 16, 16, 16),
            new Rectangle(16, 16, 16, 16),
            new Rectangle(32, 16, 16, 16),
            new Rectangle(48, 16, 16, 16),
            new Rectangle(64, 16, 16, 16),
            new Rectangle(80, 16, 16, 16),
            new Rectangle(96, 16, 16, 16),
            new Rectangle(112, 16, 16, 16),
            new Rectangle(128, 16, 16, 16),
            new Rectangle(144, 16, 16, 16),
            new Rectangle(160, 16, 16, 16),
            new Rectangle(176, 16, 16, 16),
            new Rectangle(192, 16, 16, 16),
            new Rectangle(208, 16, 16, 16),
            new Rectangle(224, 16, 16, 16),
            new Rectangle(240, 16, 16, 16),
            new Rectangle(0, 32, 16, 16),
            new Rectangle(16, 32, 16, 16),
            new Rectangle(32, 32, 16, 16),
            new Rectangle(48, 32, 16, 16),
            new Rectangle(64, 32, 16, 16),
            new Rectangle(80, 32, 16, 16),
            new Rectangle(96, 32, 16, 16),
            new Rectangle(112, 32, 16, 16),
            new Rectangle(128, 32, 16, 16),
            new Rectangle(144, 32, 16, 16),
            new Rectangle(160, 32, 16, 16),
            new Rectangle(176, 32, 16, 16),
            new Rectangle(192, 32, 16, 16),
            new Rectangle(208, 32, 16, 16),
            new Rectangle(224, 32, 16, 16),
            new Rectangle(240, 32, 16, 16),
            new Rectangle(0, 48, 16, 16),
            new Rectangle(16, 48, 16, 16),
            new Rectangle(32, 48, 16, 16),
            new Rectangle(48, 48, 16, 16),
            new Rectangle(64, 48, 16, 16),
            new Rectangle(80, 48, 16, 16),
            new Rectangle(96, 48, 16, 16),
            new Rectangle(112, 48, 16, 16),
            new Rectangle(128, 48, 16, 16),
            new Rectangle(144, 48, 16, 16),
            new Rectangle(160, 48, 16, 16),
            new Rectangle(176, 48, 16, 16),
            new Rectangle(192, 48, 16, 16),
            new Rectangle(208, 48, 16, 16),
            new Rectangle(224, 48, 16, 16),
            new Rectangle(240, 48, 16, 16),
            new Rectangle(0, 64, 16, 16),
            new Rectangle(16, 64, 16, 16),
            new Rectangle(32, 64, 16, 16),
            new Rectangle(48, 64, 16, 16),
            new Rectangle(64, 64, 16, 16),
            new Rectangle(80, 64, 16, 16),
            new Rectangle(96, 64, 16, 16),
            new Rectangle(112, 64, 16, 16),
            new Rectangle(128, 64, 16, 16),
            new Rectangle(144, 64, 16, 16),
            new Rectangle(160, 64, 16, 16),
            new Rectangle(176, 64, 16, 16),
            new Rectangle(192, 64, 16, 16),
            new Rectangle(208, 64, 16, 16),
            new Rectangle(224, 64, 16, 16),
            new Rectangle(240, 64, 16, 16),
            new Rectangle(0, 80, 16, 16),
            new Rectangle(16, 80, 16, 16),
            new Rectangle(32, 80, 16, 16),
            new Rectangle(48, 80, 16, 16),
            new Rectangle(64, 80, 16, 16),
            new Rectangle(80, 80, 16, 16),
            new Rectangle(96, 80, 16, 16),
            new Rectangle(112, 80, 16, 16),
            new Rectangle(128, 80, 16, 16),
            new Rectangle(144, 80, 16, 16),
            new Rectangle(160, 80, 16, 16),
            new Rectangle(176, 80, 16, 16),
            new Rectangle(192, 80, 16, 16),
            new Rectangle(208, 80, 16, 16),
            new Rectangle(224, 80, 16, 16),
            new Rectangle(240, 80, 16, 16),
            new Rectangle(0, 96, 16, 16),
            new Rectangle(16, 96, 16, 16),
            new Rectangle(32, 96, 16, 16),
            new Rectangle(48, 96, 16, 16),
            new Rectangle(64, 96, 16, 16),
            new Rectangle(80, 96, 16, 16),
            new Rectangle(96, 96, 16, 16),
            new Rectangle(112, 96, 16, 16),
            new Rectangle(128, 96, 16, 16),
            new Rectangle(144, 96, 16, 16),
            new Rectangle(160, 96, 16, 16),
            new Rectangle(176, 96, 16, 16),
            new Rectangle(192, 96, 16, 16),
            new Rectangle(208, 96, 16, 16),
            new Rectangle(224, 96, 16, 16),
            new Rectangle(240, 96, 16, 16),
            new Rectangle(0, 112, 16, 16),
            new Rectangle(16, 112, 16, 16),
            new Rectangle(32, 112, 16, 16),
            new Rectangle(48, 112, 16, 16),
            new Rectangle(64, 112, 16, 16),
            new Rectangle(80, 112, 16, 16),
            new Rectangle(96, 112, 16, 16),
            new Rectangle(112, 112, 16, 16),
            new Rectangle(128, 112, 16, 16),
            new Rectangle(144, 112, 16, 16),
            new Rectangle(160, 112, 16, 16),
            new Rectangle(176, 112, 16, 16),
            new Rectangle(192, 112, 16, 16),
            new Rectangle(208, 112, 16, 16),
            new Rectangle(224, 112, 16, 16),
            new Rectangle(240, 112, 16, 16),
            new Rectangle(0, 128, 16, 16),
            new Rectangle(16, 128, 16, 16),
            new Rectangle(32, 128, 16, 16),
            new Rectangle(48, 128, 16, 16),
            new Rectangle(64, 128, 16, 16),
            new Rectangle(80, 128, 16, 16),
            new Rectangle(96, 128, 16, 16),
            new Rectangle(112, 128, 16, 16),
            new Rectangle(128, 128, 16, 16),
            new Rectangle(144, 128, 16, 16),
            new Rectangle(160, 128, 16, 16),
            new Rectangle(176, 128, 16, 16),
            new Rectangle(192, 128, 16, 16),
            new Rectangle(208, 128, 16, 16),
            new Rectangle(224, 128, 16, 16),
            new Rectangle(240, 128, 16, 16),
            new Rectangle(0, 144, 16, 16),
            new Rectangle(16, 144, 16, 16),
            new Rectangle(32, 144, 16, 16),
            new Rectangle(48, 144, 16, 16),
            new Rectangle(64, 144, 16, 16),
            new Rectangle(80, 144, 16, 16),
            new Rectangle(96, 144, 16, 16),
            new Rectangle(112, 144, 16, 16),
            new Rectangle(128, 144, 16, 16),
            new Rectangle(144, 144, 16, 16),
            new Rectangle(160, 144, 16, 16),
            new Rectangle(176, 144, 16, 16),
            new Rectangle(192, 144, 16, 16),
            new Rectangle(208, 144, 16, 16),
            new Rectangle(224, 144, 16, 16),
            new Rectangle(240, 144, 16, 16),
            new Rectangle(0, 160, 16, 16),
            new Rectangle(16, 160, 16, 16),
            new Rectangle(32, 160, 16, 16),
            new Rectangle(48, 160, 16, 16),
            new Rectangle(64, 160, 16, 16),
            new Rectangle(80, 160, 16, 16),
            new Rectangle(96, 160, 16, 16),
            new Rectangle(112, 160, 16, 16),
            new Rectangle(128, 160, 16, 16),
            new Rectangle(144, 160, 16, 16),
            new Rectangle(160, 160, 16, 16),
            new Rectangle(176, 160, 16, 16),
            new Rectangle(192, 160, 16, 16),
            new Rectangle(208, 160, 16, 16),
            new Rectangle(224, 160, 16, 16),
            new Rectangle(240, 160, 16, 16),
            new Rectangle(0, 176, 16, 16),
            new Rectangle(16, 176, 16, 16),
            new Rectangle(32, 176, 16, 16),
            new Rectangle(48, 176, 16, 16),
            new Rectangle(64, 176, 16, 16),
            new Rectangle(80, 176, 16, 16),
            new Rectangle(96, 176, 16, 16),
            new Rectangle(112, 176, 16, 16),
            new Rectangle(128, 176, 16, 16),
            new Rectangle(144, 176, 16, 16),
            new Rectangle(160, 176, 16, 16),
            new Rectangle(176, 176, 16, 16),
            new Rectangle(192, 176, 16, 16),
            new Rectangle(208, 176, 16, 16),
            new Rectangle(224, 176, 16, 16),
            new Rectangle(240, 176, 16, 16),
            new Rectangle(0, 192, 16, 16),
            new Rectangle(16, 192, 16, 16),
            new Rectangle(32, 192, 16, 16),
            new Rectangle(48, 192, 16, 16),
            new Rectangle(64, 192, 16, 16),
            new Rectangle(80, 192, 16, 16),
            new Rectangle(96, 192, 16, 16),
            new Rectangle(112, 192, 16, 16),
            new Rectangle(128, 192, 16, 16),
            new Rectangle(144, 192, 16, 16),
            new Rectangle(160, 192, 16, 16),
            new Rectangle(176, 192, 16, 16),
            new Rectangle(192, 192, 16, 16),
            new Rectangle(208, 192, 16, 16),
            new Rectangle(224, 192, 16, 16),
            new Rectangle(240, 192, 16, 16),
            new Rectangle(0, 208, 16, 16),
            new Rectangle(16, 208, 16, 16),
            new Rectangle(32, 208, 16, 16),
            new Rectangle(48, 208, 16, 16),
            new Rectangle(64, 208, 16, 16),
            new Rectangle(80, 208, 16, 16),
            new Rectangle(96, 208, 16, 16),
            new Rectangle(112, 208, 16, 16),
            new Rectangle(128, 208, 16, 16),
            new Rectangle(144, 208, 16, 16),
            new Rectangle(160, 208, 16, 16),
            new Rectangle(176, 208, 16, 16),
            new Rectangle(192, 208, 16, 16),
            new Rectangle(208, 208, 16, 16),
            new Rectangle(224, 208, 16, 16),
            new Rectangle(240, 208, 16, 16),
            new Rectangle(0, 224, 16, 16),
            new Rectangle(16, 224, 16, 16),
            new Rectangle(32, 224, 16, 16),
            new Rectangle(48, 224, 16, 16),
            new Rectangle(64, 224, 16, 16),
            new Rectangle(80, 224, 16, 16),
            new Rectangle(96, 224, 16, 16),
            new Rectangle(112, 224, 16, 16),
            new Rectangle(128, 224, 16, 16),
            new Rectangle(144, 224, 16, 16),
            new Rectangle(160, 224, 16, 16),
            new Rectangle(176, 224, 16, 16),
            new Rectangle(192, 224, 16, 16),
            new Rectangle(208, 224, 16, 16),
            new Rectangle(224, 224, 16, 16),
            new Rectangle(240, 224, 16, 16),
            new Rectangle(0, 240, 16, 16),
            new Rectangle(16, 240, 16, 16),
            new Rectangle(32, 240, 16, 16),
            new Rectangle(48, 240, 16, 16),
            new Rectangle(64, 240, 16, 16),
            new Rectangle(80, 240, 16, 16),
            new Rectangle(96, 240, 16, 16),
            new Rectangle(112, 240, 16, 16),
            new Rectangle(128, 240, 16, 16),
            new Rectangle(144, 240, 16, 16),
            new Rectangle(160, 240, 16, 16),
            new Rectangle(176, 240, 16, 16),
            new Rectangle(192, 240, 16, 16),
            new Rectangle(208, 240, 16, 16),
            new Rectangle(224, 240, 16, 16),
            new Rectangle(240, 240, 16, 16),
        };
        public List<Rectangle> collisionRectangles;
        private const int TILESIZE = 32;

        Texture2D pixel; ///temporary

        public void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            pixel = new Texture2D(graphicsDevice, 1, 1);//temporary
            pixel.SetData(new[] { Color.White });//temp
            textureAtlas = content.Load<Texture2D>("world_tileset");
            fg.tilemap = fg.LoadMap("../../../Content/Maps/Level1_fg.csv");
            fg.textureStore = tileMapTextureStore;

            mg.tilemap = mg.LoadMap("../../../Content/Maps/Level1_mg.csv");
            mg.textureStore = tileMapTextureStore;

            bg.tilemap = bg.LoadMap("../../../Content/Maps/Level1_bg.csv");
            bg.textureStore = tileMapTextureStore;

            collisionMap = content.Load<Texture2D>("collision");
            collision.tilemap = collision.LoadMap("../../../Content/Maps/Level1_collisions.csv");
            collision.textureStore = new () { new Rectangle(0, 0, 16, 16) };

            collisionRectangles = new List<Rectangle>();
            foreach (var item in collision.tilemap)
            {
                Rectangle dest = new
                    (
                    (int)item.Key.X * TILESIZE,
                    (int)item.Key.Y * TILESIZE,
                    TILESIZE,
                    TILESIZE
                    );
                collisionRectangles.Add(dest);
            }

            Texture2D playerTexture = content.Load<Texture2D>("player_spritesheet");
            Texture2D enemyTexture = content.Load<Texture2D>("slime_green_spritesheet");
            Texture2D coinTexture = content.Load<Texture2D>("coin_spritesheet");

            bgMusic = content.Load<Song>("time_for_adventure");

            player = new Player(playerTexture, new Vector2(416, 1500));
            player.LoadContent(content, graphicsDevice);

            enemies.Add(new Enemy(enemyTexture, new Vector2(900, 1600)));
            enemies.Add(new Enemy(enemyTexture, new Vector2(990, 1600)));
            foreach (Enemy enemy in enemies)
            {
                enemy.LoadContent(content, graphicsDevice);
            }

            coins.Add(new Collectible(coinTexture, new Vector2(616, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(648, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(680, 1600)));

            coins.Add(new Collectible(coinTexture, new Vector2(1512, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(1544, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(1576, 1600)));

            coins.Add(new Collectible(coinTexture, new Vector2(2456, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2488, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2520, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2552, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2584, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2616, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2648, 1328)));

            coins.Add(new Collectible(coinTexture, new Vector2(2344, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2376, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2408, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2440, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2472, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2504, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2536, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2568, 1768)));
            coins.Add(new Collectible(coinTexture, new Vector2(2600, 1768)));

            coins.Add(new Collectible(coinTexture, new Vector2(2344, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2376, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2408, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2440, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2472, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2504, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2536, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2568, 1800)));
            coins.Add(new Collectible(coinTexture, new Vector2(2600, 1800)));

            foreach (Collectible coin in coins)
            {
                coin.LoadContent(content, graphicsDevice);
            }
        }

        public void update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
            camera.Update(screenSize);
        }

        public void playMusic()
        {
            MediaPlayer.Stop();
            MediaPlayer.Play(bgMusic);
        }

        public void Update(GameTime gameTime)
        {       
            foreach (Rectangle tile in collisionRectangles)
            {
                player.HandleCollision(tile);
                foreach (Enemy enemy in enemies)
                {
                    enemy.HandleCollision(tile);
                }
            }
            player.Update(gameTime);
            camera.Follow(player.Hitbox);

            foreach (Enemy enemy in enemies)
            {
                enemy.Update(gameTime);

                if (!enemy.touchedPlayer && player.Hitbox.Intersects(enemy.Hitbox) && player.velocity.Y > 0)
                {
                    if (player.Position.Y + player.Hitbox.Height - 5 < enemy.Position.Y)
                    {
                        player.velocity.Y = -player.jumpStrength / 1.5f;
                        player.attackSound.Play();
                        enemy.touchedPlayer = true;
                        enemy.speed = 0;
                        enemy.animationCounter = 0;
                        enemy.spritesheetRow = 24 * 2;
                        score += 5;
                    }
                    else if (!player.isHurt)
                    {
                        player.isHurt = true;
                        if (player.health > 0)
                        {
                            player.health--;
                        }
                        player.hurtSound.Play();
                    }
                }
            }

            enemies.RemoveAll(e => e.touchedPlayer && e.animationCounter >= 44);

            foreach (Collectible coin in coins)
            {
                coin.Update(gameTime);
                if (!coin.collected && player.Hitbox.Intersects(coin.Hitbox))
                {
                    coin.collected = true;
                    coin.coinSound.Play();
                    score++;
                }
            }

            coins.RemoveAll(coin => coin.collected);

            if (player.health <= 0 && player.isAlive)
            {
                player.isAlive = false;
                player.animationCounter = 0;
                player.spritesheetRow = 32 * 7;
                player.hurtSound.Play();
            }

            if (!player.isAlive && player.animationCounter >= 44)
            {
                player.animationCounter = 40;
                player.animationFrame = 3;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            bg.Draw(spriteBatch, textureAtlas, camera.Position, 16, 16);
            mg.Draw(spriteBatch, textureAtlas, camera.Position, 16, 16);
            fg.Draw(spriteBatch, textureAtlas, camera.Position, 16, 16);


            //collision.Draw(spriteBatch, collisionMap, camera.Position, 16, 16);//debugging

            //spriteBatch.Draw(pixel, new Rectangle(player.Hitbox.X + (int)camera.Position.X, player.Hitbox.Y + (int)camera.Position.Y, player.Hitbox.Width, player.Hitbox.Height), Color.Black);//temp

            foreach (Enemy enemy in enemies)
            {     
                //spriteBatch.Draw(pixel, new Rectangle(enemy.Hitbox.X + (int)camera.Position.X, enemy.Hitbox.Y + (int)camera.Position.Y, enemy.Hitbox.Width, enemy.Hitbox.Height), Color.Black); //temp
                enemy.Draw(spriteBatch, camera.Position);
            }
            foreach (Collectible coin in coins)
            {
                //spriteBatch.Draw(pixel, new Rectangle(coin.Hitbox.X + (int)camera.Position.X, coin.Hitbox.Y + (int)camera.Position.Y, coin.Hitbox.Width, coin.Hitbox.Height), Color.Black); // temp
                coin.Draw(spriteBatch, camera.Position);
            }
            player.Draw(spriteBatch, camera.Position);
        }
    }
}
