﻿using Hollow_Quest.Entities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Timers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection.Metadata;

namespace Hollow_Quest.World
{
    public class Level
    {
        public Player player;
        public int score = 0;

        private List<Enemy> enemies = new List<Enemy>();
        private Boss demon;

        private List<Collectible> coins = new List<Collectible>();
        private List<Collectible> healFruits = new List<Collectible>();
        private Collectible spicyFruit;
        private Collectible stickyFruit;
        private Collectible ballFruit;

        private Texture2D textureAtlas;
        private TileMap fg = new TileMap();
        private TileMap mg = new TileMap();
        private TileMap bg = new TileMap();

        private Texture2D collisionMap;
        private TileMap collision = new TileMap();

        private readonly List<Rectangle> tileMapTextureStore = new()
        {
            new Rectangle(0, 0, 16, 16),
            new Rectangle(16, 0, 16, 16),
            new Rectangle(32, 0, 16, 16),
            new Rectangle(48, 0, 16, 16),
            new Rectangle(64, 0, 16, 16),
            new Rectangle(80, 0, 16, 16),
            new Rectangle(96, 0, 16, 16),
            new Rectangle(112, 0, 16, 16),
            new Rectangle(128, 0, 16, 16),
            new Rectangle(144, 0, 16, 16),
            new Rectangle(160, 0, 16, 16),
            new Rectangle(176, 0, 16, 16),
            new Rectangle(192, 0, 16, 16),
            new Rectangle(208, 0, 16, 16),
            new Rectangle(224, 0, 16, 16),
            new Rectangle(240, 0, 16, 16),
            new Rectangle(0, 16, 16, 16),
            new Rectangle(16, 16, 16, 16),
            new Rectangle(32, 16, 16, 16),
            new Rectangle(48, 16, 16, 16),
            new Rectangle(64, 16, 16, 16),
            new Rectangle(80, 16, 16, 16),
            new Rectangle(96, 16, 16, 16),
            new Rectangle(112, 16, 16, 16),
            new Rectangle(128, 16, 16, 16),
            new Rectangle(144, 16, 16, 16),
            new Rectangle(160, 16, 16, 16),
            new Rectangle(176, 16, 16, 16),
            new Rectangle(192, 16, 16, 16),
            new Rectangle(208, 16, 16, 16),
            new Rectangle(224, 16, 16, 16),
            new Rectangle(240, 16, 16, 16),
            new Rectangle(0, 32, 16, 16),
            new Rectangle(16, 32, 16, 16),
            new Rectangle(32, 32, 16, 16),
            new Rectangle(48, 32, 16, 16),
            new Rectangle(64, 32, 16, 16),
            new Rectangle(80, 32, 16, 16),
            new Rectangle(96, 32, 16, 16),
            new Rectangle(112, 32, 16, 16),
            new Rectangle(128, 32, 16, 16),
            new Rectangle(144, 32, 16, 16),
            new Rectangle(160, 32, 16, 16),
            new Rectangle(176, 32, 16, 16),
            new Rectangle(192, 32, 16, 16),
            new Rectangle(208, 32, 16, 16),
            new Rectangle(224, 32, 16, 16),
            new Rectangle(240, 32, 16, 16),
            new Rectangle(0, 48, 16, 16),
            new Rectangle(16, 48, 16, 16),
            new Rectangle(32, 48, 16, 16),
            new Rectangle(48, 48, 16, 16),
            new Rectangle(64, 48, 16, 16),
            new Rectangle(80, 48, 16, 16),
            new Rectangle(96, 48, 16, 16),
            new Rectangle(112, 48, 16, 16),
            new Rectangle(128, 48, 16, 16),
            new Rectangle(144, 48, 16, 16),
            new Rectangle(160, 48, 16, 16),
            new Rectangle(176, 48, 16, 16),
            new Rectangle(192, 48, 16, 16),
            new Rectangle(208, 48, 16, 16),
            new Rectangle(224, 48, 16, 16),
            new Rectangle(240, 48, 16, 16),
            new Rectangle(0, 64, 16, 16),
            new Rectangle(16, 64, 16, 16),
            new Rectangle(32, 64, 16, 16),
            new Rectangle(48, 64, 16, 16),
            new Rectangle(64, 64, 16, 16),
            new Rectangle(80, 64, 16, 16),
            new Rectangle(96, 64, 16, 16),
            new Rectangle(112, 64, 16, 16),
            new Rectangle(128, 64, 16, 16),
            new Rectangle(144, 64, 16, 16),
            new Rectangle(160, 64, 16, 16),
            new Rectangle(176, 64, 16, 16),
            new Rectangle(192, 64, 16, 16),
            new Rectangle(208, 64, 16, 16),
            new Rectangle(224, 64, 16, 16),
            new Rectangle(240, 64, 16, 16),
            new Rectangle(0, 80, 16, 16),
            new Rectangle(16, 80, 16, 16),
            new Rectangle(32, 80, 16, 16),
            new Rectangle(48, 80, 16, 16),
            new Rectangle(64, 80, 16, 16),
            new Rectangle(80, 80, 16, 16),
            new Rectangle(96, 80, 16, 16),
            new Rectangle(112, 80, 16, 16),
            new Rectangle(128, 80, 16, 16),
            new Rectangle(144, 80, 16, 16),
            new Rectangle(160, 80, 16, 16),
            new Rectangle(176, 80, 16, 16),
            new Rectangle(192, 80, 16, 16),
            new Rectangle(208, 80, 16, 16),
            new Rectangle(224, 80, 16, 16),
            new Rectangle(240, 80, 16, 16),
            new Rectangle(0, 96, 16, 16),
            new Rectangle(16, 96, 16, 16),
            new Rectangle(32, 96, 16, 16),
            new Rectangle(48, 96, 16, 16),
            new Rectangle(64, 96, 16, 16),
            new Rectangle(80, 96, 16, 16),
            new Rectangle(96, 96, 16, 16),
            new Rectangle(112, 96, 16, 16),
            new Rectangle(128, 96, 16, 16),
            new Rectangle(144, 96, 16, 16),
            new Rectangle(160, 96, 16, 16),
            new Rectangle(176, 96, 16, 16),
            new Rectangle(192, 96, 16, 16),
            new Rectangle(208, 96, 16, 16),
            new Rectangle(224, 96, 16, 16),
            new Rectangle(240, 96, 16, 16),
            new Rectangle(0, 112, 16, 16),
            new Rectangle(16, 112, 16, 16),
            new Rectangle(32, 112, 16, 16),
            new Rectangle(48, 112, 16, 16),
            new Rectangle(64, 112, 16, 16),
            new Rectangle(80, 112, 16, 16),
            new Rectangle(96, 112, 16, 16),
            new Rectangle(112, 112, 16, 16),
            new Rectangle(128, 112, 16, 16),
            new Rectangle(144, 112, 16, 16),
            new Rectangle(160, 112, 16, 16),
            new Rectangle(176, 112, 16, 16),
            new Rectangle(192, 112, 16, 16),
            new Rectangle(208, 112, 16, 16),
            new Rectangle(224, 112, 16, 16),
            new Rectangle(240, 112, 16, 16),
            new Rectangle(0, 128, 16, 16),
            new Rectangle(16, 128, 16, 16),
            new Rectangle(32, 128, 16, 16),
            new Rectangle(48, 128, 16, 16),
            new Rectangle(64, 128, 16, 16),
            new Rectangle(80, 128, 16, 16),
            new Rectangle(96, 128, 16, 16),
            new Rectangle(112, 128, 16, 16),
            new Rectangle(128, 128, 16, 16),
            new Rectangle(144, 128, 16, 16),
            new Rectangle(160, 128, 16, 16),
            new Rectangle(176, 128, 16, 16),
            new Rectangle(192, 128, 16, 16),
            new Rectangle(208, 128, 16, 16),
            new Rectangle(224, 128, 16, 16),
            new Rectangle(240, 128, 16, 16),
            new Rectangle(0, 144, 16, 16),
            new Rectangle(16, 144, 16, 16),
            new Rectangle(32, 144, 16, 16),
            new Rectangle(48, 144, 16, 16),
            new Rectangle(64, 144, 16, 16),
            new Rectangle(80, 144, 16, 16),
            new Rectangle(96, 144, 16, 16),
            new Rectangle(112, 144, 16, 16),
            new Rectangle(128, 144, 16, 16),
            new Rectangle(144, 144, 16, 16),
            new Rectangle(160, 144, 16, 16),
            new Rectangle(176, 144, 16, 16),
            new Rectangle(192, 144, 16, 16),
            new Rectangle(208, 144, 16, 16),
            new Rectangle(224, 144, 16, 16),
            new Rectangle(240, 144, 16, 16),
            new Rectangle(0, 160, 16, 16),
            new Rectangle(16, 160, 16, 16),
            new Rectangle(32, 160, 16, 16),
            new Rectangle(48, 160, 16, 16),
            new Rectangle(64, 160, 16, 16),
            new Rectangle(80, 160, 16, 16),
            new Rectangle(96, 160, 16, 16),
            new Rectangle(112, 160, 16, 16),
            new Rectangle(128, 160, 16, 16),
            new Rectangle(144, 160, 16, 16),
            new Rectangle(160, 160, 16, 16),
            new Rectangle(176, 160, 16, 16),
            new Rectangle(192, 160, 16, 16),
            new Rectangle(208, 160, 16, 16),
            new Rectangle(224, 160, 16, 16),
            new Rectangle(240, 160, 16, 16),
            new Rectangle(0, 176, 16, 16),
            new Rectangle(16, 176, 16, 16),
            new Rectangle(32, 176, 16, 16),
            new Rectangle(48, 176, 16, 16),
            new Rectangle(64, 176, 16, 16),
            new Rectangle(80, 176, 16, 16),
            new Rectangle(96, 176, 16, 16),
            new Rectangle(112, 176, 16, 16),
            new Rectangle(128, 176, 16, 16),
            new Rectangle(144, 176, 16, 16),
            new Rectangle(160, 176, 16, 16),
            new Rectangle(176, 176, 16, 16),
            new Rectangle(192, 176, 16, 16),
            new Rectangle(208, 176, 16, 16),
            new Rectangle(224, 176, 16, 16),
            new Rectangle(240, 176, 16, 16),
            new Rectangle(0, 192, 16, 16),
            new Rectangle(16, 192, 16, 16),
            new Rectangle(32, 192, 16, 16),
            new Rectangle(48, 192, 16, 16),
            new Rectangle(64, 192, 16, 16),
            new Rectangle(80, 192, 16, 16),
            new Rectangle(96, 192, 16, 16),
            new Rectangle(112, 192, 16, 16),
            new Rectangle(128, 192, 16, 16),
            new Rectangle(144, 192, 16, 16),
            new Rectangle(160, 192, 16, 16),
            new Rectangle(176, 192, 16, 16),
            new Rectangle(192, 192, 16, 16),
            new Rectangle(208, 192, 16, 16),
            new Rectangle(224, 192, 16, 16),
            new Rectangle(240, 192, 16, 16),
            new Rectangle(0, 208, 16, 16),
            new Rectangle(16, 208, 16, 16),
            new Rectangle(32, 208, 16, 16),
            new Rectangle(48, 208, 16, 16),
            new Rectangle(64, 208, 16, 16),
            new Rectangle(80, 208, 16, 16),
            new Rectangle(96, 208, 16, 16),
            new Rectangle(112, 208, 16, 16),
            new Rectangle(128, 208, 16, 16),
            new Rectangle(144, 208, 16, 16),
            new Rectangle(160, 208, 16, 16),
            new Rectangle(176, 208, 16, 16),
            new Rectangle(192, 208, 16, 16),
            new Rectangle(208, 208, 16, 16),
            new Rectangle(224, 208, 16, 16),
            new Rectangle(240, 208, 16, 16),
            new Rectangle(0, 224, 16, 16),
            new Rectangle(16, 224, 16, 16),
            new Rectangle(32, 224, 16, 16),
            new Rectangle(48, 224, 16, 16),
            new Rectangle(64, 224, 16, 16),
            new Rectangle(80, 224, 16, 16),
            new Rectangle(96, 224, 16, 16),
            new Rectangle(112, 224, 16, 16),
            new Rectangle(128, 224, 16, 16),
            new Rectangle(144, 224, 16, 16),
            new Rectangle(160, 224, 16, 16),
            new Rectangle(176, 224, 16, 16),
            new Rectangle(192, 224, 16, 16),
            new Rectangle(208, 224, 16, 16),
            new Rectangle(224, 224, 16, 16),
            new Rectangle(240, 224, 16, 16),
            new Rectangle(0, 240, 16, 16),
            new Rectangle(16, 240, 16, 16),
            new Rectangle(32, 240, 16, 16),
            new Rectangle(48, 240, 16, 16),
            new Rectangle(64, 240, 16, 16),
            new Rectangle(80, 240, 16, 16),
            new Rectangle(96, 240, 16, 16),
            new Rectangle(112, 240, 16, 16),
            new Rectangle(128, 240, 16, 16),
            new Rectangle(144, 240, 16, 16),
            new Rectangle(160, 240, 16, 16),
            new Rectangle(176, 240, 16, 16),
            new Rectangle(192, 240, 16, 16),
            new Rectangle(208, 240, 16, 16),
            new Rectangle(224, 240, 16, 16),
            new Rectangle(240, 240, 16, 16),
        };
        private readonly List<Rectangle> collisionMapTextureStore = new() 
        { 
            new Rectangle(0, 0, 16, 16),
            new Rectangle(16, 0, 16, 16),
            new Rectangle(32, 0, 16, 16),
        };
        public List<Rectangle> redCollisionRectangles;
        public List<Rectangle> yellowCollisionRectangles;
        public List<Rectangle> blueCollisionRectangles;
        private const int TILESIZE = 32;

        private Song bgMusic;
        private Camera camera = new Camera(Vector2.Zero, new Vector2(800, 480));
        private Vector2 screenSize;

        Texture2D playerTexture;
        Texture2D greenSlimeTexture;
        Texture2D coinTexture;
        Texture2D stickyFruitTexture;
        Texture2D spicyFruitTexture;
        Texture2D healFruitTexture;
        Texture2D ballFruitTexture;
        Texture2D demonTexture;

        public void Initialize()
        {
            player.Initialize();
            foreach (var enemy in enemies)
            {
                enemy.Initialize();
            }
            foreach (var coin in coins)
            {
                coin.Initialize();
            }
            foreach (var fruit in healFruits)
            {
                fruit.Initialize();
            }
            spicyFruit.Initialize();
            stickyFruit.Initialize();
            ballFruit.Initialize();
            demon.Initialize();
        }

        public void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            LoadMapData(content);
            LoadEntityData(content);
            bgMusic = content.Load<Song>("BGM/time_for_adventure");

            InitializeEntities(content, graphicsDevice);
        }

        public void Update(GameTime gameTime)
        {
            HandleMapCollisions();
            player.Update(gameTime);
            HandleEntityCollisions();
            camera.Follow(player.Hitbox);
            foreach (Enemy enemy in enemies)
            {
                enemy.Update(gameTime);
            }
            foreach (Collectible coin in coins)
            {
                coin.Update(gameTime);
                coin.HandleAnimations();
            }
            foreach (Collectible healFruit in healFruits)
            {
                healFruit.Update(gameTime);
            }
            spicyFruit.Update(gameTime);
            stickyFruit.Update(gameTime);
            ballFruit.Update(gameTime);
            demon.Update(gameTime);

            HandlePlayerDeath();

            demon.GetPlayerPosition(player.Position);
            demon.HandleStartFight();    
            if (demon.state == Boss.BossState.Dead && !player.bossDefeated)
            {
                score += 50;
                player.bossDefeated = true;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            DrawMap(spriteBatch);
            foreach (Enemy enemy in enemies)
            {
                enemy.Draw(spriteBatch, camera.Position);
            }
            DrawCollectibles(spriteBatch);
            demon.Draw(spriteBatch, camera.Position);
            player.Draw(spriteBatch, camera.Position);      
        }

        private void LoadMapData(ContentManager content)
        {
            textureAtlas = content.Load<Texture2D>("Maps/world_tileset");
            fg.tilemap = fg.LoadMap("../../../Content/Maps/Level1_fg.csv");
            mg.tilemap = mg.LoadMap("../../../Content/Maps/Level1_mg.csv");
            bg.tilemap = bg.LoadMap("../../../Content/Maps/Level1_bg.csv");

            collisionMap = content.Load<Texture2D>("Maps/collision_map");
            collision.tilemap = collision.LoadMap("../../../Content/Maps/Level1_collisions.csv");
            redCollisionRectangles = new List<Rectangle>(); // Only horizontal collisions
            yellowCollisionRectangles = new List<Rectangle>(); // Both horizontal and vertical collisions
            blueCollisionRectangles = new List<Rectangle>(); // Only horizontal collisions with wall jump effect
            foreach (var item in collision.tilemap)
            {
                if (item.Value == 0) // red collisions
                {
                    Rectangle dest = new
                    (
                    (int)item.Key.X * TILESIZE,
                    (int)item.Key.Y * TILESIZE,
                    TILESIZE,
                    TILESIZE
                    );
                    redCollisionRectangles.Add(dest);
                }
                else if (item.Value == 1) // blue collisions
                {
                    Rectangle dest = new
                    (
                    (int)item.Key.X * TILESIZE,
                    (int)item.Key.Y * TILESIZE,
                    TILESIZE,
                    TILESIZE
                    );
                    blueCollisionRectangles.Add(dest);
                }
                else if (item.Value == 2) // yellow collisions
                {
                    Rectangle dest = new
                    (
                    (int)item.Key.X * TILESIZE,
                    (int)item.Key.Y * TILESIZE,
                    TILESIZE,
                    TILESIZE
                    );
                    yellowCollisionRectangles.Add(dest);
                }
            }
        }

        private void LoadEntityData(ContentManager content)
        {
            playerTexture = content.Load<Texture2D>("player_spritesheet");
            greenSlimeTexture = content.Load<Texture2D>("Enemies/slime_green");
            coinTexture = content.Load<Texture2D>("Collectibles/coin");
            stickyFruitTexture = content.Load<Texture2D>("Collectibles/sticky_fruit");
            spicyFruitTexture = content.Load<Texture2D>("Collectibles/spicy_fruit");
            healFruitTexture = content.Load<Texture2D>("Collectibles/heal_fruit");
            ballFruitTexture = content.Load<Texture2D>("Collectibles/ball_fruit");
            demonTexture = content.Load<Texture2D>("Enemies/boss_spritesheet");
        }

        private void InitializeEntities(ContentManager content, GraphicsDevice graphicsDevice)
        {
            player = new Player(playerTexture, new Vector2(416, 1500));
            player.LoadContent(content, graphicsDevice);

            StartPositionEnemies();
            ; foreach (Enemy enemy in enemies)
            {
                enemy.LoadContent(content, graphicsDevice);
            }

            StartPositionCollectibles();
            foreach (Collectible coin in coins)
            {
                coin.LoadContent(content, graphicsDevice);
            }
            foreach (Collectible healFruit in healFruits)
            {
                healFruit.LoadContent(content, graphicsDevice);
            }
            stickyFruit.LoadContent(content, graphicsDevice);
            spicyFruit.LoadContent(content, graphicsDevice);
            ballFruit.LoadContent(content, graphicsDevice);

            demon = new Boss(demonTexture, new Vector2(2600, 300));
            demon.LoadContent(content, graphicsDevice); 
        }

        private void StartPositionEnemies()
        {
            enemies.Clear();
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(900, 1600)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1000, 1600)));

            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1100, 1200)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1200, 1200)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1300, 1200)));

            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1570, 1090)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1620, 1090)));

            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1730, 1090)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1780, 1090)));

            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1800, 750)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1850, 750)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1650, 750)));
            enemies.Add(new Enemy(greenSlimeTexture, new Vector2(1550, 750)));
        }

        private void StartPositionCollectibles()
        {
            coins.Clear();
            healFruits.Clear();
            // coins
            coins.Add(new Collectible(coinTexture, new Vector2(616, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(648, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(680, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(712, 1600)));

            coins.Add(new Collectible(coinTexture, new Vector2(1512, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(1544, 1600)));
            coins.Add(new Collectible(coinTexture, new Vector2(1576, 1600)));
            
            coins.Add(new Collectible(coinTexture, new Vector2(2488, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2520, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2552, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2584, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2616, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2648, 1328)));
            coins.Add(new Collectible(coinTexture, new Vector2(2680, 1328)));

            coins.Add(new Collectible(coinTexture, new Vector2(2344, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2376, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2408, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2440, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2472, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2504, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2536, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2568, 1672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2600, 1672)));

            coins.Add(new Collectible(coinTexture, new Vector2(2344, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2376, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2408, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2440, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2472, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2504, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2536, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2568, 1704)));
            coins.Add(new Collectible(coinTexture, new Vector2(2600, 1704)));

            coins.Add(new Collectible(coinTexture, new Vector2(1416, 1184)));
            coins.Add(new Collectible(coinTexture, new Vector2(1448, 1184)));
            coins.Add(new Collectible(coinTexture, new Vector2(1480, 1184)));
            coins.Add(new Collectible(coinTexture, new Vector2(1512, 1184)));

            coins.Add(new Collectible(coinTexture, new Vector2(1736, 1184)));
            coins.Add(new Collectible(coinTexture, new Vector2(1768, 1184)));
            coins.Add(new Collectible(coinTexture, new Vector2(1800, 1184)));
     
            coins.Add(new Collectible(coinTexture, new Vector2(1192, 1096)));
            coins.Add(new Collectible(coinTexture, new Vector2(1224, 1096)));
            coins.Add(new Collectible(coinTexture, new Vector2(1256, 1096)));

            coins.Add(new Collectible(coinTexture, new Vector2(2120, 1096)));
            coins.Add(new Collectible(coinTexture, new Vector2(2152, 1096)));
            coins.Add(new Collectible(coinTexture, new Vector2(2184, 1096)));

            coins.Add(new Collectible(coinTexture, new Vector2(2152, 672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2184, 672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2216, 672)));
            coins.Add(new Collectible(coinTexture, new Vector2(2248, 672)));

            // fruits
            healFruits.Add(new Collectible(healFruitTexture, new Vector2(2760, 1360)));
            spicyFruit = new Collectible(spicyFruitTexture, new Vector2(2760, 1328));

            ballFruit = new Collectible(ballFruitTexture, new Vector2(584, 1224));

            healFruits.Add(new Collectible(healFruitTexture, new Vector2(1688, 968)));
            stickyFruit = new Collectible(stickyFruitTexture, new Vector2(3112, 968));
            healFruits.Add(new Collectible(healFruitTexture, new Vector2(2520, 1064)));

        }

        private void HandleMapCollisions()
        {
            foreach (Rectangle tile in redCollisionRectangles)
            {
                player.HandleRedCollision(tile);
                if (player.rollHitBox.Intersects(tile))
                {
                    player.GetRollDisplacement(tile);
                }
                foreach (Enemy enemy in enemies)
                {
                    enemy.HandleRedCollision(tile);
                }
            }
            
            foreach (Rectangle tile in blueCollisionRectangles)
            {
                player.HandleBlueCollision(tile);
                if (player.rollHitBox.Intersects(tile))
                {
                    player.GetRollDisplacement(tile);
                }
            }

            foreach (Rectangle tile in yellowCollisionRectangles)
            {
                player.HandleYellowCollision(tile);
                if (player.rollHitBox.Intersects(tile))
                {
                    player.GetRollDisplacement(tile);
                }
                foreach (Enemy enemy in enemies)
                {
                    enemy.HandleYellowCollision(tile);
                }
            }
        }

        private void HandleEntityCollisions()
        {
            HandleEnemeyCollisions();
            HandleBossCollisions();
            HandleCollectibleCollisions();
        }

        private void HandleEnemeyCollisions()
        {
            foreach (Enemy enemy in enemies)
            {
                if (player.Hitbox.Intersects(enemy.Hitbox) && !enemy.touchedPlayer) // Player jumps on enemy
                {
                    if (player.Hitbox.Bottom - 10 < enemy.Position.Y && player.velocity.Y > 0)
                    {
                        player.velocity.Y = -player.jumpStrength / 1.5f;
                        player.attackSound.Play();
                        enemy.touchedPlayer = true;
                        enemy.speed = 0;
                        enemy.animationCounter = 0;
                        enemy.spritesheetRow = 24 * 2;
                        score += 5;
                    }
                    else if (!player.isHurt) // Enemy hurts player
                    {
                        player.isHurt = true;
                        if (player.health > 0)
                        {
                            player.health--;
                            player.animation = Player.PlayerAnimation.Hurt;
                            player.animationCounter = 0;
                            player.animationFrame = 0;
                        }
                        player.hurtSound.Play();
                    }
                }
            }
            enemies.RemoveAll(e => e.touchedPlayer && e.animationCounter >= 44);
        }

        private void HandleBossCollisions()
        {
            if (player.Hitbox.Intersects(demon.Hitbox) && demon.animation != Boss.BossAnimation.Hurt && demon.state != Boss.BossState.Dead)
            {
                if (player.Hitbox.Bottom - 20 < demon.Hitbox.Top && player.velocity.Y > 0) // Player jumps on boss
                {
                    player.velocity.Y = -player.jumpStrength / 1.5f;
                    player.attackSound.Play();
                    demon.speed = 0;
                    demon.animationCounter = 0;
                    demon.animationFrame = 0;
                    demon.animation = Boss.BossAnimation.Hurt;
                    demon.Health -= 1;
                }
                else if (!player.isHurt) // Boss hurts player
                {
                    player.isHurt = true;
                    if (player.health > 0)
                    {
                        player.health--;
                        player.animation = Player.PlayerAnimation.Hurt;
                        player.animationCounter = 0;
                        player.animationFrame = 0;
                    }
                    player.hurtSound.Play();
                }
            }

            if (player.Hitbox.Intersects(demon.hurtbox)) // Boss hurts player with weapon
            {
                if (!player.isHurt)
                {
                    player.isHurt = true;
                    if (player.health > 0)
                    {
                        player.health--;
                        player.animation = Player.PlayerAnimation.Hurt;
                        player.animationCounter = 0;
                        player.animationFrame = 0;
                    }
                    player.hurtSound.Play();
                }
            }

            if (demon.fireballs != null)
            {
                foreach (Fireball fireball in demon.fireballs)
                {
                    if (player.Hitbox.Intersects(fireball.Hitbox)) // Boss fireball hurts player
                    {
                        if (!player.isHurt)
                        {
                            player.isHurt = true;
                            if (player.health > 0)
                            {
                                player.health--;
                                player.animation = Player.PlayerAnimation.Hurt;
                                player.animationCounter = 0;
                                player.animationFrame = 0;
                            }
                            player.hurtSound.Play();
                        }
                    }
                }
            }      
        }

        private void HandleCollectibleCollisions()
        {
            foreach (Collectible coin in coins)
            {
                if (!coin.collected && player.Hitbox.Intersects(coin.Hitbox))
                {
                    coin.collected = true;
                    coin.coinSound.Play();
                    score++;
                }
            }
            coins.RemoveAll(coin => coin.collected);
            foreach (Collectible healFruit in healFruits)
            {
                if (!healFruit.collected && player.Hitbox.Intersects(healFruit.Hitbox))
                {
                    healFruit.collected = true;
                    healFruit.eatingSound.Play();
                    if (player.health < 5)
                    {
                        player.health++;
                        score += 5;
                    }
                    else
                    {
                        score += 10;
                    }
                }
            }
            healFruits.RemoveAll(healFruit => healFruit.collected);
            if (!stickyFruit.collected && player.Hitbox.Intersects(stickyFruit.Hitbox))
            {
                stickyFruit.collected = true;
                stickyFruit.eatingSound.Play();
                player.canWallJump = true;
                score += 10;
            }
            if (!spicyFruit.collected && player.Hitbox.Intersects(spicyFruit.Hitbox))
            {
                spicyFruit.collected = true;
                spicyFruit.eatingSound.Play();
                player.canDoubleJump = true;
                score += 10;
            }
            if (!ballFruit.collected && player.Hitbox.Intersects(ballFruit.Hitbox))
            {
                ballFruit.collected = true;
                ballFruit.eatingSound.Play();
                player.canRoll = true;
                score += 10;
            }
        }

        private void HandlePlayerDeath()
        {
            if (player.health <= 0 && player.isAlive)
            {
                player.isAlive = false;
                player.canDoubleJump = false;
                player.canWallJump = false;
                player.animationCounter = 0;
                player.animationFrame = 0;
                player.spritesheetRow = 32 * 7;
                player.hurtSound.Play();
            }
        }

        private void DrawMap(SpriteBatch spriteBatch)
        {
            bg.Draw(spriteBatch, textureAtlas, camera.Position, tileMapTextureStore);
            mg.Draw(spriteBatch, textureAtlas, camera.Position, tileMapTextureStore);
            fg.Draw(spriteBatch, textureAtlas, camera.Position, tileMapTextureStore);
        }

        private void DrawCollectibles (SpriteBatch spriteBatch)
        {
            foreach (Collectible coin in coins)
            {
                coin.Draw(spriteBatch, camera.Position);
            }
            foreach (Collectible healFruit in healFruits)
            {
                healFruit.Draw(spriteBatch, camera.Position);
            }
            stickyFruit.Draw(spriteBatch, camera.Position);
            spicyFruit.Draw(spriteBatch, camera.Position);
            ballFruit.Draw(spriteBatch, camera.Position);
        }

        public void Update(Vector2 screenSize)
        {
            this.screenSize = screenSize;
            camera.Update(screenSize);
        }

        public void PlayMusic()
        {
            MediaPlayer.Stop();
            MediaPlayer.Play(bgMusic);
        }
    }
}
