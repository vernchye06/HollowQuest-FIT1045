﻿using var game = new Hollow_Quest.Game1();
game.Run();
